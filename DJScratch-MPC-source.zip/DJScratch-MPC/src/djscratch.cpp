// DJ Scratch - scratch the audio coming into an MPC track, submix or the master. A native MPC OS VST2 insert effect
// (Gen1, 32-bit ARM), built the same way as the SP1200 plugin: dependency-free VST2 core (src/vst2.h), one parameter
// table, a skin drawn by tools/make_skin.py, needs only libc/libm.
//
// The DSP is in src/scratch/Scratch.h. This file: parameters, presets (VST programs), host tempo, MIDI notes, the status
// readout, the I/O thread (SAMPLE source loading, REC to WAV), entry points.
//
// Files live in "<drive>/DJ Scratch/": WAVs in Samples/ (and Recordings/) are the records for the SAMPLE source; REC writes
// Recordings/DJScratch-NNN.wav. <drive> is the MPC's internal drive (/media/az01-internal), else /sdcard; DJSCRATCH_DIR
// overrides the whole folder (tests). All disk access is on one background thread; the audio thread only hands buffers over.
#include "scratch/Scratch.h"
#include "fileio.h"
#include "vst2.h"
#include <pthread.h>
#include <unistd.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <new>

#define DS_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace ds;

enum ParamId
{
    P_PLATTER, P_HOLD, P_AUTO, P_RELEASE, P_THROW, P_INERTIA,
    P_FADER, P_CHOP, P_BACKSPIN,
    P_RETURN, P_CATCH, P_SPINSPEED, P_SPINTIME, P_CHOPMS, P_CUTMS, P_OUTPUT, P_BYPASS,
    P_LOOP, P_LOOPLEN, P_BPM, P_TFORM, P_TRATE, P_TDUTY, P_TPAT,
    P_SOURCE, P_SAMPLE, P_PLAY, P_CUE, P_THRU, P_REC, P_RESCAN,
    P_STARTT, P_STOPT, P_BRAKE, P_RPM, P_PITCH, P_PRANGE, P_PFINE, P_PRESET, P_BEND, P_REV,
    P_RECSRC, P_PREROLL, P_THRESH, P_AFTER, P_SAVELAST, P_LASTLEN, P_BUFLEN,
    P_ROLL4, P_ROLL8, P_ROLL16, P_ROLL32,
    P_SPIN, P_INMETER,
    P_INFO,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG, K_TEXT, K_METER };     // K_TEXT / K_METER: read-outs the plugin drives
enum Fmt { F_NUM, F_DB, F_SEC, F_MS, F_X, F_PLATTER, F_BPM, F_PCT, F_SAMPLE, F_PITCH, F_FINE, F_BEND, F_SPIN, F_METER };
constexpr int kMaxFiles = 128;
constexpr double kMaxSampleSec = 90.0;

const char* const kReturns[] { "Slip (jump)", "Catch up" };
const char* const kSources[] { "Live Input", "Sample" };
const char* const kRpm[] { "33", "45" };
const char* const kRanges[] { "+/-8 %", "+/-16 %", "+/-50 %" };
const double kRangePct[] { 8.0, 16.0, 50.0 };
constexpr double kBendPct = 4.0;                        // a full nudge on BEND = +/-4 %, like a hand on the platter edge
const char* const kRecSrc[] { "Output", "Input" };
const char* const kPreroll[] { "Off", "0.5 s", "1 s", "2 s", "4 s" };
const double kPrerollSec[] { 0.0, 0.5, 1.0, 2.0, 4.0 };
const char* const kThresh[] { "On sound", "-48 dB", "-36 dB", "-24 dB", "Instant" };
const float kThreshLin[] { 1e-4f, 0.00398f, 0.01585f, 0.0631f, -1.f };
const char* const kAfter[] { "As is", "Fades", "Normalize" };
const char* const kLastLen[] { "1 bar", "2 bars", "4 bars", "8 bars", "All" };
const double kLastBars[] { 1, 2, 4, 8, 0 };
const char* const kBufLen[] { "10 s", "20 s", "40 s", "60 s" };
const double kBufSec[] { 10, 20, 40, 60 };
// note values, in quarter-note beats (a quarter note = 1 beat)
const char* const kLoopNames[] { "1/32", "1/16T", "1/16", "1/8T", "1/8", "1/4T", "1/4", "1/2", "1 Bar" };
const double kLoopBeats[] { 0.125, 1.0 / 6.0, 0.25, 1.0 / 3.0, 0.5, 2.0 / 3.0, 1.0, 2.0, 4.0 };
const char* const kRateNames[] { "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32" };
const double kRateBeats[] { 1.0, 0.5, 1.0 / 3.0, 0.25, 1.0 / 6.0, 0.125 };
const char* const kPatNames[] { "Straight", "Offbeat", "Gallop", "Syncopated" };
const uint32_t kPatMask[] { 0xFFFFu, 0xAAAAu, 0xDDDDu, 0x4949u };     // 16 steps; Gallop = X.XX, Syncopated = X..X..X. (3+3+2)

struct ParamDef
{
    const char* key; const char* name; const char* unit; Kind kind; float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt;
};
#define CH(a) a, (int) (sizeof (a) / sizeof (a[0]))
ParamDef kParams[P_COUNT];
void initParams()
{
    auto f = [] (int i, const char* key, const char* name, const char* unit, Kind k, float lo, float hi, float step, float def, Fmt fm)
    { kParams[i] = { key, name, unit, k, lo, hi, step, def, nullptr, 0, fm }; };
    auto c = [] (int i, const char* key, const char* name, const char* const* ch, int n, int def)
    { kParams[i] = { key, name, "", K_CHOICE, 0, (float) (n - 1), 1, (float) def, ch, n, F_NUM }; };
    f (P_PLATTER, "platter", "Platter", "", K_FLOAT, 0, 1, 0, 0.5f, F_PLATTER);
    f (P_HOLD, "hold", "Hold", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_AUTO, "auto", "Auto Grab", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_RELEASE, "release", "Auto Release", "s", K_LOG, 0.1f, 4.f, 0, 0.4f, F_SEC);
    f (P_THROW, "throw", "Throw", "s", K_LOG, 0.25f, 4.f, 0, 1.f, F_SEC);
    f (P_INERTIA, "inertia", "Inertia", "ms", K_LOG, 3.f, 60.f, 0, 12.f, F_MS);
    f (P_FADER, "fader", "Fader Closed", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_CHOP, "chop", "Chop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BACKSPIN, "backspin", "Backspin", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RETURN, "return", "Return", CH (kReturns), 0);
    f (P_CATCH, "catch", "Catch-up Speed", "x", K_FLOAT, 1.5f, 8.f, 0.1f, 3.f, F_X);
    f (P_SPINSPEED, "spinspeed", "Spin Speed", "x", K_FLOAT, 2.f, 16.f, 0.5f, 8.f, F_X);
    f (P_SPINTIME, "spintime", "Spin Time", "s", K_LOG, 0.3f, 4.f, 0, 1.2f, F_SEC);
    f (P_CHOPMS, "chopms", "Chop Length", "ms", K_LOG, 10.f, 500.f, 0, 80.f, F_MS);
    f (P_CUTMS, "cutms", "Fader Time", "ms", K_LOG, 0.5f, 20.f, 0, 2.f, F_MS);
    f (P_OUTPUT, "output", "Output", "dB", K_FLOAT, -24, 12, 0.1f, 0, F_DB);
    f (P_BYPASS, "bypass", "Bypass", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_LOOP, "loop", "Loop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_LOOPLEN, "looplen", "Loop Length", CH (kLoopNames), 4);
    f (P_BPM, "bpm", "Tempo", "BPM", K_FLOAT, 0, 240, 1, 0, F_BPM);
    f (P_TFORM, "tform", "Transformer", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_TRATE, "trate", "Gate Rate", CH (kRateNames), 3);
    f (P_TDUTY, "tduty", "Gate Open", "%", K_FLOAT, 10, 100, 1, 50, F_PCT);
    c (P_TPAT, "tpat", "Gate Pattern", CH (kPatNames), 0);
    c (P_SOURCE, "source", "Source", CH (kSources), 0);
    f (P_SAMPLE, "sample", "Sample", "", K_FLOAT, 0, (float) (kMaxFiles - 1), 1, 0, F_SAMPLE);
    f (P_PLAY, "play", "Play", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_CUE, "cue", "Cue", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_THRU, "thru", "Input Thru", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_REC, "rec", "Record", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_RESCAN, "rescan", "Rescan", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_STARTT, "startt", "Start Time", "s", K_LOG, 0.1f, 4.f, 0, 0.5f, F_SEC);
    f (P_STOPT, "stopt", "Stop Time", "s", K_LOG, 0.1f, 8.f, 0, 0.8f, F_SEC);
    f (P_BRAKE, "brake", "Brake", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RPM, "rpm", "Speed", CH (kRpm), 0);
    f (P_PITCH, "pitch", "Pitch", "%", K_FLOAT, -1, 1, 0, 0, F_PITCH);
    c (P_PRANGE, "prange", "Pitch Range", CH (kRanges), 0);
    f (P_PFINE, "pfine", "Fine Pitch", "%", K_FLOAT, -1, 1, 0.01f, 0, F_FINE);
    f (P_PRESET, "pitchreset", "Pitch Reset", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BEND, "bend", "Bend", "%", K_FLOAT, -1, 1, 0, 0, F_BEND);
    f (P_REV, "reverse", "Reverse", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RECSRC, "recsrc", "Rec Source", CH (kRecSrc), 0);
    c (P_PREROLL, "preroll", "Pre-roll", CH (kPreroll), 0);
    c (P_THRESH, "thresh", "Rec Start", CH (kThresh), 0);
    c (P_AFTER, "after", "After Rec", CH (kAfter), 0);
    f (P_SAVELAST, "savelast", "Save Last", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_LASTLEN, "lastlen", "Save Length", CH (kLastLen), 1);
    c (P_BUFLEN, "buflen", "History", CH (kBufLen), 1);
    f (P_ROLL4, "roll4", "Loop 1/4", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL8, "roll8", "Loop 1/8", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL16, "roll16", "Loop 1/16", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL32, "roll32", "Loop 1/32", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    kParams[P_SPIN] = { "spin", "Record Angle", "", K_METER, 0, 1, 0, 0, nullptr, 0, F_SPIN };
    kParams[P_INMETER] = { "inmeter", "Input Level", "", K_METER, 0, 1, 0, 0, nullptr, 0, F_METER };
    kParams[P_INFO] = { "info", "Status", "", K_TEXT, 0, 1000, 0, 0, nullptr, 0, F_NUM };
}
inline bool isTrigger (int i) { return i == P_CHOP || i == P_BACKSPIN || i == P_CUE || i == P_RESCAN || i == P_BRAKE || i == P_PRESET || i == P_SAVELAST; }
inline bool isReadout (int i) { return kParams[i].kind == K_TEXT || kParams[i].kind == K_METER; }
// controls the presets leave alone (the performance state, and the SAMPLE / REC setup)
inline bool keptByPresets (int i)
{
    return i == P_PLATTER || i == P_HOLD || i == P_BYPASS || i == P_LOOP || i == P_BPM || isTrigger (i) || isReadout (i)
        || i >= P_SOURCE;                                   // the deck (motor, pitch), the sample and the sampler setup
}

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}

// ---------------------------------------------------------------------------------------------- presets
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }
PRESET (pClassic, { P_AUTO, 1 })
PRESET (pTight, { P_INERTIA, 5.f }, { P_THROW, 0.5f }, { P_RELEASE, 0.25f })
PRESET (pHeavy, { P_INERTIA, 35.f }, { P_THROW, 1.5f }, { P_RELEASE, 0.6f })
PRESET (pLong, { P_THROW, 3.f }, { P_RELEASE, 0.8f }, { P_INERTIA, 18.f })
PRESET (pSlip, { P_RETURN, 0 }, { P_RELEASE, 0.3f })
PRESET (pCatch, { P_RETURN, 1 }, { P_CATCH, 4.f }, { P_RELEASE, 0.35f })
PRESET (pManual, { P_AUTO, 0 })
PRESET (pTransform, { P_FADER, 1 }, { P_CHOPMS, 60.f }, { P_CUTMS, 1.f })
PRESET (pHardSpin, { P_SPINSPEED, 12.f }, { P_SPINTIME, 2.f })
PRESET (pSoftSpin, { P_SPINSPEED, 5.f }, { P_SPINTIME, 0.8f })
PRESET (pAutoT, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 0 }, { P_TDUTY, 50 })
PRESET (pGallop, { P_TFORM, 1 }, { P_TRATE, 1 }, { P_TPAT, 2 }, { P_TDUTY, 70 })
PRESET (pSync, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 3 }, { P_TDUTY, 60 })
PRESET (pTripCut, { P_TFORM, 1 }, { P_TRATE, 2 }, { P_TPAT, 1 }, { P_TDUTY, 80 })
PRESET (pLoop8, { P_LOOPLEN, 4 })
PRESET (pLoop16, { P_LOOPLEN, 2 })
PRESET (pLoop4, { P_LOOPLEN, 6 })
const Preset kPresets[] =
{
    ENTRY ("Classic Scratch", pClassic), ENTRY ("Tight Wrist", pTight), ENTRY ("Heavy Platter", pHeavy), ENTRY ("Long Throw", pLong),
    ENTRY ("Slip Mode", pSlip), ENTRY ("Catch Up", pCatch), ENTRY ("Manual Grab", pManual), ENTRY ("Hand Transformer", pTransform),
    ENTRY ("Hard Backspin", pHardSpin), ENTRY ("Soft Backspin", pSoftSpin),
    ENTRY ("Auto Transformer", pAutoT), ENTRY ("Gallop Gate", pGallop), ENTRY ("Syncopated Gate", pSync), ENTRY ("Triplet Cut", pTripCut),
    ENTRY ("Loop 1/8", pLoop8), ENTRY ("Loop 1/16", pLoop16), ENTRY ("Loop 1/4", pLoop4),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

// ---------------------------------------------------------------------------------------------- plugin
struct Text
{
    char buf[2][128] {}; std::atomic<int> live { 0 };
    const char* get() const { return buf[live.load()]; }
    bool publish (const char* s)
    {
        if (std::strcmp (get(), s) == 0) return false;
        const int idle = 1 - live.load(); std::snprintf (buf[idle], sizeof buf[idle], "%s", s); live.store (idle); return true;
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;
    std::atomic<float> v[P_COUNT], nv[P_COUNT];
    std::atomic<int> pending[P_COUNT];     // taps received on the trigger keys, consumed by the audio thread
    std::atomic<uint32_t> noteMask { 0 };  // MIDI notes held (pitch classes C..G# = loop lengths)
    std::atomic<int> noteLast { -1 };      // the loop length the latest held note selects
    std::atomic<int> tformDirty { 0 };     // a MIDI note flipped the transformer: tell the host
    int loopIdxActive = 4;
    double bpmUsed = 120.0; int tempoSrc = 2;   // 0 manual, 1 host, 2 default
    float sent[P_COUNT];
    int program = 0;
    float sr = 44100.f;
    Engine engine;
    Text info; int infoGen = 0;
    int displayCountdown = 0;

    // ---- files: the I/O thread owns the disk; these are its hand-over points
    std::atomic<float> srA { 44100.f };
    pthread_t ioThread {}; bool ioStarted = false; std::atomic<bool> ioQuit { false }; std::atomic<bool> dirsOk { false };
    char baseDir[256] {}, smpDir[320] {}, recDir[320] {};
    // the file list: written by the I/O thread only, read by the host thread (parameter display) under a sequence lock
    struct Files { std::atomic<uint32_t> seq { 0 }; int count = 0; char rel[kMaxFiles][128]; char shown[kMaxFiles][64]; } files;
    std::atomic<int> rescanReq { 1 };
    char scanTmp[kMaxFiles][128];                                // I/O thread scratch space for a folder listing
    // the record on the platter (SAMPLE source): I/O thread -> next -> audio thread (cur) -> retired -> I/O thread frees it
    std::atomic<dsio::Sample*> next { nullptr }, retired { nullptr };
    dsio::Sample* cur = nullptr;
    char loadedRel[128] {}; float loadedSr = 0; char failedRel[128] {};
    // REC: the audio thread pushes its output into a FIFO, the I/O thread writes it to a 24-bit WAV
    static constexpr uint32_t kFifoFrames = 1u << 19;            // ~11 s at 48 kHz: room for 4 s of pre-roll plus a slow card
    static constexpr int kChunk = 1024;                            // process() works in chunks of at most this many frames
    static constexpr uint32_t kPreFrames = 1u << 19;               // pre-roll history of the record source (4 s up to 96 kHz)
    float* pre = nullptr; uint32_t preW = 0;                       // audio thread
    int preSrc = -1;
    float inCopy[2][kChunk];                                       // the input, kept before the output overwrites it (in-place hosts)
    // the deck
    // LOOP ROLL keys (DECK page): one at a time, like beat-repeat buttons. Index into kLoopNames: 1/4, 1/8, 1/16, 1/32.
    static constexpr int kRollParam[4] { P_ROLL4, P_ROLL8, P_ROLL16, P_ROLL32 };
    static constexpr int kRollLoop[4] { 6, 4, 2, 0 };
    bool rollWas[4] {}; int rollActive = -1;
    bool braking = false; float lastBend = 0; int bendIdle = 0; double angle = 0; int visualCountdown = 0;
    // SAVE LAST: the audio thread asks, the I/O thread copies the history to a WAV
    std::atomic<int64_t> lastEnd { 0 }, lastLen { 0 }; std::atomic<uint32_t> lastGen { 0 }; uint32_t lastDone = 0; char lastLabel[16] {};
    // the history buffer (HISTORY): the I/O thread allocates a new ring, the audio thread swaps it in
    std::atomic<float*> nextRing { nullptr }, retiredRing { nullptr }; std::atomic<uint32_t> nextRingFrames { 0 }, ringFramesNow { 0 };
    std::atomic<int> preparing { 0 }, ioCopying { 0 };
    float* fifo = nullptr;
    std::atomic<uint32_t> fw { 0 }, fr { 0 };                    // frames written / read (wrap around)
    std::atomic<uint32_t> recGen { 0 };                          // odd while a take is running
    std::atomic<bool> writerIdle { true };
    std::atomic<uint32_t> recFrames { 0 }, recDropped { 0 };
    int recPhase = 0;                                            // audio thread: 0 off, 1 armed (waits for sound), 2 recording
    dsio::WavWriter wav; bool wOpen = false, wFail = false; uint32_t doneGen = 0; char takeName[64] {};
    Text ioMsg; std::atomic<int> ioMsgGen { 0 }; int seenMsgGen = 0; int msgLeft = 0;

    Plugin()
    {
        for (int i = 0; i < P_COUNT; ++i) { setPlain (i, kParams[i].def); sent[i] = 1e9f; pending[i].store (0); }
        engine.prepare (sr);
        fifo = (float*) std::calloc ((size_t) kFifoFrames * 2, sizeof (float));
        pre = (float*) std::calloc ((size_t) kPreFrames * 2, sizeof (float));
        engine.setRingSeconds (kBufSec[clampi ((int) kParams[P_BUFLEN].def, 0, 3)]);
        engine.prepare (sr);
        ringFramesNow.store (engine.ringSize());
    }
    // host thread: (re)prepare the engine, never while the I/O thread is reading the history
    void prepareEngine (float rate)
    {
        preparing.store (1);
        while (ioCopying.load() != 0) usleep (500);
        engine.setRingSeconds (kBufSec[clampi ((int) get (P_BUFLEN), 0, 3)]);
        engine.prepare (rate);
        ringFramesNow.store (engine.ringSize());
        preparing.store (0);
    }
    ~Plugin()
    {
        stopIO();
        dsio::freeSample (next.exchange (nullptr)); dsio::freeSample (retired.exchange (nullptr)); dsio::freeSample (cur); cur = nullptr;
        std::free (fifo); fifo = nullptr; std::free (pre); pre = nullptr;
        std::free (nextRing.exchange (nullptr)); std::free (retiredRing.exchange (nullptr));
    }
    void setPlain (int i, float plain) { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
    void setNorm (int i, float norm)
    {
        const ParamDef& d = kParams[i];
        if (isReadout (i)) return;
        norm = clampf (norm, 0.f, 1.f);
        nv[i].store (norm); v[i].store (toPlain (d, norm));
        if (isTrigger (i) && norm >= 0.5f) pending[i].fetch_add (1);       // a tap
    }
    float get (int i) const { return v[i].load(); }
    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        for (int p = 0; p < P_COUNT; ++p)
            if (! keptByPresets (p)) setPlain (p, kParams[p].def);
        for (int k = 0; k < kPresets[i].n; ++k) setPlain (kPresets[i].ov[k].id, kPresets[i].ov[k].v);
    }
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i) if (! isReadout (i)) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
        master (&fx, audioMasterUpdateDisplay, 0, 0, nullptr, 0.f);
    }
    double pitchPct() const
    {
        return (double) get (P_PITCH) * kRangePct[clampi ((int) get (P_PRANGE), 0, 2)] + (double) get (P_PFINE) + (double) get (P_BEND) * kBendPct;
    }
    double speedNow() const { return (get (P_RPM) > 0.5f ? 1.35 : 1.0) * (1.0 + pitchPct() / 100.0); }
    Settings settings() const
    {
        Settings s;
        s.platter = get (P_PLATTER); s.hold = get (P_HOLD) > 0.5f; s.autoGrab = get (P_AUTO) > 0.5f; s.releaseSec = get (P_RELEASE);
        s.throwSec = get (P_THROW); s.inertiaMs = get (P_INERTIA); s.faderClosed = get (P_FADER) > 0.5f; s.chopMs = get (P_CHOPMS);
        s.cutMs = get (P_CUTMS); s.spinSpeed = get (P_SPINSPEED); s.spinSec = get (P_SPINTIME); s.returnMode = (int) get (P_RETURN);
        s.catchSpeed = get (P_CATCH); s.outDb = get (P_OUTPUT); s.bypass = get (P_BYPASS) > 0.5f;
        s.deck = get (P_SOURCE) > 0.5f; s.motorOn = get (P_PLAY) > 0.5f; s.thru = get (P_THRU) > 0.5f;
        s.speed = speedNow(); s.reverse = get (P_REV) > 0.5f;
        s.startSec = get (P_STARTT); s.stopSec = braking ? 0.12f : get (P_STOPT);
        return s;
    }


    // ================================================================ I/O thread
    void say (const char* fmt, const char* a, double x = 0)
    {
        char b[128]; std::snprintf (b, sizeof b, fmt, a, x);
        ioMsg.publish (b); ioMsgGen.fetch_add (1);
    }
    bool setupDirs()
    {
        const char* env = std::getenv ("DJSCRATCH_DIR");
        const char* cands[] { env, "/media/az01-internal/DJ Scratch", "/sdcard/DJ Scratch" };
        for (const char* c : cands)
        {
            if (c == nullptr || c[0] == 0) continue;
            char parent[256]; std::snprintf (parent, sizeof parent, "%s", c);
            char* sl = std::strrchr (parent, '/'); if (sl != nullptr && sl != parent) *sl = 0;
            if (c != env && ! dsio::isDir (parent)) continue;                    // that drive isn't there
            std::snprintf (baseDir, sizeof baseDir, "%s", c);
            std::snprintf (smpDir, sizeof smpDir, "%s/Samples", c);
            std::snprintf (recDir, sizeof recDir, "%s/Recordings", c);
            if (dsio::makeDirs (smpDir) && dsio::makeDirs (recDir)) return true;
        }
        baseDir[0] = 0;
        return false;
    }
    void scan()
    {
        int n = 0;
        files.seq.fetch_add (1);                             // odd: the list is being rewritten
        const char* dirs[] { smpDir, recDir };
        const char* sub[] { "Samples", "Recordings" };
        for (int d = 0; d < 2 && n < kMaxFiles; ++d)
        {
            const int k = dsio::listWavs (dirs[d], scanTmp, kMaxFiles - n);
            for (int j = 0; j < k; ++j, ++n)
            {
                std::snprintf (files.rel[n], sizeof files.rel[n], "%s/%s", sub[d], scanTmp[j]);
                char nm[64]; dsio::baseName (scanTmp[j], nm, sizeof nm);
                std::snprintf (files.shown[n], sizeof files.shown[n], d == 1 ? "REC %s" : "%s", nm);
            }
        }
        files.count = n;
        files.seq.fetch_add (1);
        failedRel[0] = 0;                                    // a rescan retries a file that failed to load
    }
    void serviceLoader()
    {
        const int n = files.count;
        if (n == 0) return;
        const int idx = PluginClamp ((int) get (P_SAMPLE), 0, kMaxFiles - 1);
        if (idx >= n) return;
        const float sr = srA.load();
        if (std::strcmp (files.rel[idx], loadedRel) == 0 && loadedSr == sr) return;
        if (std::strcmp (files.rel[idx], failedRel) == 0) return;
        if (next.load() != nullptr || retired.load() != nullptr) return;          // the audio thread hasn't taken the last one yet
        char path[640]; std::snprintf (path, sizeof path, "%s/%s", baseDir, files.rel[idx]);
        char err[64] = "";
        dsio::Sample* smp = dsio::loadWav (path, sr, kMaxSampleSec, err, sizeof err);
        if (smp == nullptr)
        {
            std::snprintf (failedRel, sizeof failedRel, "%s", files.rel[idx]);
            char nm[64], m[128]; dsio::baseName (files.rel[idx], nm, sizeof nm); std::snprintf (m, sizeof m, "%s: %s", nm, err);
            say ("CAN'T LOAD %s", m); return;
        }
        std::snprintf (loadedRel, sizeof loadedRel, "%s", files.rel[idx]); loadedSr = sr;
        next.store (smp);
        if (smp->truncated) say ("LOADED %s (first 90 s)", smp->name);
        else say ("LOADED %s  %.1f s", smp->name, (double) smp->len / sr);
    }
    void serviceRecorder()
    {
        const uint32_t g = recGen.load();
        if (! wOpen && ! wFail && g != doneGen)                                   // a take started: open its file
        {
            char path[640];
            std::snprintf (takeName, sizeof takeName, "DJScratch-%03d.wav", dsio::nextTakeNumber (recDir));
            std::snprintf (path, sizeof path, "%s/%s", recDir, takeName);
            if (wav.open (path, (uint32_t) std::lround (srA.load()))) wOpen = true;
            else { wFail = true; say ("REC: CAN'T WRITE %s", recDir); }
        }
        uint32_t r = fr.load (std::memory_order_relaxed);
        const uint32_t w = fw.load (std::memory_order_acquire);
        while (r != w)
        {
            const uint32_t idx = r & (kFifoFrames - 1);
            uint32_t m = w - r; if (m > kFifoFrames - idx) m = kFifoFrames - idx;
            if (wOpen && ! wav.write (fifo + (size_t) idx * 2, m))
            {
                wav.close(); wOpen = false; wFail = true; say ("REC: DISK FULL OR REMOVED (%s)", takeName);
            }
            r += m;
            fr.store (r, std::memory_order_release);
        }
        if ((g & 1u) == 0 && g != doneGen && fr.load() == fw.load())                // the take stopped and everything is on disk
        {
            if (wOpen)
            {
                const double sec = (double) wav.frames / (double) wav.rate;
                bool ok = wav.close();
                if (ok) ok = finishFile (takeName);
                if (ok) say ("SAVED %s  %.1f s", takeName, sec); else say ("REC: ERROR CLOSING %s", takeName);
                rescanReq.store (1);
            }
            wOpen = false; wFail = false; doneGen = g;
            writerIdle.store (true);
        }
    }
    // fades / normalize after a take, as set in AFTER REC
    bool finishFile (const char* name)
    {
        const int after = clampi ((int) get (P_AFTER), 0, 2);
        if (after == 0) return true;
        char path[640]; std::snprintf (path, sizeof path, "%s/%s", recDir, name);
        return dsio::finishWav24 (path, after == 2, 3.0, 10.0);
    }
    // HISTORY changed (or the rate did): make a ring of the new size; the audio thread swaps it in
    void serviceRing()
    {
        const float rate = srA.load();
        const uint32_t want = Engine::ringFramesFor (rate, kBufSec[clampi ((int) get (P_BUFLEN), 0, 3)]);
        if (want == ringFramesNow.load() || nextRing.load() != nullptr || retiredRing.load() != nullptr) return;
        float* m = (float*) std::calloc ((size_t) want * 2, sizeof (float));
        if (m == nullptr) { say ("HISTORY: NOT ENOUGH MEMORY%s", ""); return; }
        nextRingFrames.store (want);
        nextRing.store (m);
    }
    // SAVE LAST: copy the last N bars of the incoming audio out of the history into a new WAV
    void serviceSaveLast()
    {
        const uint32_t g = lastGen.load();
        if (g == lastDone) return;
        lastDone = g;
        const int64_t end = lastEnd.load(), len = lastLen.load();
        if (len < 64) { say ("SAVE LAST: NOTHING RECORDED YET%s", ""); return; }
        ioCopying.store (1);
        if (preparing.load() != 0) { ioCopying.store (0); say ("SAVE LAST: TRY AGAIN%s", ""); return; }
        const uint32_t gen = engine.ringGeneration(), size = engine.ringSize();
        const float* L = engine.ringL(); const float* R = engine.ringR();
        // only copy what the audio thread can't reach while we copy: well clear of the write position
        if (len > (int64_t) size - 3 * 16384 || engine.writtenFrames() + 3 * 16384 - (end - len) > (int64_t) size)
        {
            ioCopying.store (0);
            say ("SAVE LAST: %s TOO LONG FOR THE HISTORY", lastLabel);
            return;
        }
        char name[64], path[640];
        std::snprintf (name, sizeof name, "DJScratch-%03d.wav", dsio::nextTakeNumber (recDir));
        std::snprintf (path, sizeof path, "%s/%s", recDir, name);
        dsio::WavWriter w; bool ok = w.open (path, (uint32_t) std::lround (srA.load()));
        float buf[2 * 1024];
        for (int64_t k = end - len; ok && k < end; )
        {
            const int m = (int) ((end - k) < 1024 ? (end - k) : 1024);
            for (int j = 0; j < m; ++j) { const uint32_t idx = (uint32_t) ((k + j) & (int64_t) (size - 1)); buf[2 * j] = L[idx]; buf[2 * j + 1] = R[idx]; }
            ok = w.write (buf, (uint32_t) m);
            k += m;
        }
        // still valid? (the history kept moving while we copied: the oldest part must not have been overwritten)
        const bool intact = engine.ringGeneration() == gen && engine.writtenFrames() + 16384 - (end - len) <= (int64_t) size;
        ioCopying.store (0);
        ok = w.close() && ok;
        if (ok && intact) ok = finishFile (name);
        if (! ok || ! intact)
        {
            std::remove (path);
            say (intact ? "SAVE LAST: CAN'T WRITE %s" : "SAVE LAST: %s TOO LONG FOR THE HISTORY", intact ? recDir : lastLabel);
            return;
        }
        char msg[96]; std::snprintf (msg, sizeof msg, "%s -> %s", lastLabel, name);
        say ("SAVED LAST %s", msg);
        rescanReq.store (1);
    }
    void ioLoop()
    {
        if (setupDirs()) dirsOk.store (true);
        int scanLeftMs = 0;
        while (! ioQuit.load())
        {
            dsio::freeSample (retired.exchange (nullptr));
            std::free (retiredRing.exchange (nullptr));
            if (dirsOk.load())
            {
                serviceRecorder();
                serviceRing();
                serviceSaveLast();
                const bool deck = get (P_SOURCE) > 0.5f;
                if (rescanReq.exchange (0) != 0 || (deck && scanLeftMs <= 0)) { scan(); scanLeftMs = 2000; }
                if (deck) serviceLoader();
            }
            const int ms = wOpen ? 5 : 20;
            usleep ((useconds_t) ms * 1000);
            scanLeftMs -= ms;
        }
        // closing the plugin mid-take: write what we have
        if (dirsOk.load() && (recGen.load() & 1u) != 0) recGen.fetch_add (1);
        if (dirsOk.load()) serviceRecorder();
        if (wOpen) { wav.close(); wOpen = false; }
    }
    static void* ioEntry (void* self) { static_cast<Plugin*> (self)->ioLoop(); return nullptr; }
    void startIO() { if (fifo != nullptr && pthread_create (&ioThread, nullptr, &Plugin::ioEntry, this) == 0) ioStarted = true; }
    void stopIO() { if (! ioStarted) return; ioQuit.store (true); pthread_join (ioThread, nullptr); ioStarted = false; }
    bool ioOk() const { return ioStarted && dirsOk.load(); }
    // host thread: the name shown for list entry i
    bool fileShown (int i, char* out, size_t max, int* count)
    {
        for (int tries = 0; tries < 50; ++tries)
        {
            const uint32_t a = files.seq.load (std::memory_order_acquire);
            if (a & 1u) { usleep (200); continue; }
            const int n = files.count;
            if (i >= 0 && i < n) std::snprintf (out, max, "%s", files.shown[i]); else out[0] = 0;
            std::atomic_thread_fence (std::memory_order_acquire);
            if (files.seq.load (std::memory_order_relaxed) == a) { *count = n; return i >= 0 && i < n; }
        }
        out[0] = 0; *count = 0; return false;
    }
    static int PluginClamp (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }

    // ================================================================ REC (audio thread side)
    void pushFifo (const float* l, const float* r, uint32_t m, uint32_t stride = 1)
    {
        const uint32_t w = fw.load (std::memory_order_relaxed), rd = fr.load (std::memory_order_acquire);
        const uint32_t room = kFifoFrames - (w - rd);
        uint32_t drop = 0;
        if (m > room) { drop = m - room; m = room; }
        for (uint32_t k = 0; k < m; ++k)
        {
            const uint32_t idx = (w + k) & (kFifoFrames - 1);
            fifo[idx * 2] = l[k * stride]; fifo[idx * 2 + 1] = r[k * stride];
        }
        fw.store (w + m, std::memory_order_release);
        recFrames.fetch_add (m);
        if (drop > 0) recDropped.fetch_add (drop);
    }
    // the record source (output or input) arrives here every block
    void recordBlock (const float* l, const float* r, int n)
    {
        const bool want = get (P_REC) > 0.5f && ioOk();
        const int src = clampi ((int) get (P_RECSRC), 0, 1);
        if (src != preSrc) { preSrc = src; preW = 0; }                             // a new source: the old pre-roll doesn't belong to it
        for (int i = 0; i < n; ++i) { const uint32_t idx = (preW + (uint32_t) i) & (kPreFrames - 1); pre[idx * 2] = l[i]; pre[idx * 2 + 1] = r[i]; }
        preW += (uint32_t) n;
        int from = 0;
        if (recPhase == 0 && want) recPhase = 1;
        if (recPhase == 1)
        {
            if (! want) { recPhase = 0; return; }
            if (! writerIdle.load()) return;                                       // the last take is still being written
            const float th = kThreshLin[clampi ((int) get (P_THRESH), 0, 4)];
            from = -1;
            if (th < 0.f) from = 0;                                                // Instant
            else for (int i = 0; i < n; ++i) if (std::fabs (l[i]) > th || std::fabs (r[i]) > th) { from = i; break; }
            if (from < 0) return;                                                  // armed: waits for the level
            writerIdle.store (false); recFrames.store (0); recDropped.store (0);
            recGen.fetch_add (1);
            recPhase = 2;
            // pre-roll: what the source did just before the take started
            const uint32_t endAbs = preW - (uint32_t) n + (uint32_t) from;
            uint32_t want = (uint32_t) (kPrerollSec[clampi ((int) get (P_PREROLL), 0, 4)] * (double) sr);
            if (want > endAbs) want = endAbs;
            if (want > kPreFrames - (uint32_t) kChunk - 16) want = kPreFrames - (uint32_t) kChunk - 16;
            for (uint32_t k = endAbs - want; k != endAbs; )
            {
                const uint32_t idx = k & (kPreFrames - 1);
                uint32_t m = endAbs - k; if (m > kPreFrames - idx) m = kPreFrames - idx;
                pushFifo (pre + idx * 2, pre + idx * 2 + 1, m, 2);
                k += m;
            }
        }
        if (recPhase != 2) return;
        pushFifo (l + from, r + from, (uint32_t) (n - from));
        if (! want) { recGen.fetch_add (1); recPhase = 0; }                       // stop after this block
    }

    // ---------------------------------------------------------------- MIDI notes (if the host sends them to an insert)
    // C..G# hold a loop of the matching length (see kLoopNames), A = backspin, A# = chop, B = transformer on/off.
    void midiNote (int note, bool on)
    {
        const int pc = note % 12;
        if (on)
        {
            if (pc < 9) { noteMask.fetch_or (1u << pc); noteLast.store (pc); }
            else if (pc == 9) pending[P_BACKSPIN].fetch_add (1);
            else if (pc == 10) pending[P_CHOP].fetch_add (1);
            else { setPlain (P_TFORM, get (P_TFORM) > 0.5f ? 0.f : 1.f); tformDirty.store (1); }
        }
        else if (pc < 9)
        {
            const uint32_t m = noteMask.fetch_and (~(1u << pc)) & ~(1u << pc);
            if (noteLast.load() == pc) { int k = -1; for (int b = 8; b >= 0; --b) if (m & (1u << b)) { k = b; break; } noteLast.store (k); }
        }
    }
    void midiEvents (const VstEvents* ev)
    {
        if (ev == nullptr) return;
        int n = ev->numEvents; if (n > 256) n = 256;
        const VstEvent* const* arr = &ev->events[0];
        for (int i = 0; i < n; ++i)
        {
            const VstEvent* e = arr[i];
            if (e == nullptr || e->type != kVstMidiType) continue;
            const VstMidiEvent* m = reinterpret_cast<const VstMidiEvent*> (e);
            const int st = m->midiData[0] & 0xF0, d1 = m->midiData[1] & 0x7F, d2 = m->midiData[2] & 0x7F;
            if (st == 0x90 && d2 > 0) midiNote (d1, true);
            else if (st == 0x80 || st == 0x90) midiNote (d1, false);
            else if (st == 0xB0 && (d1 == 123 || d1 == 120)) { noteMask.store (0); noteLast.store (-1); }     // all notes off
        }
    }
    // tempo and transport from the host; the BPM control overrides it
    void readHostTime (Settings& s)
    {
        double hostTempo = 0; s.ppqValid = false; s.ppq = 0;
        if (master != nullptr)
        {
            const intptr_t r = master (&fx, audioMasterGetTime, 0, kVstTempoValid | kVstPpqPosValid, nullptr, 0.f);
            const VstTimeInfo* ti = reinterpret_cast<const VstTimeInfo*> (r);
            if (ti != nullptr)
            {
                if ((ti->flags & kVstTempoValid) != 0 && ti->tempo >= 20.0 && ti->tempo <= 400.0) hostTempo = ti->tempo;
                if ((ti->flags & kVstPpqPosValid) != 0 && (ti->flags & kVstTransportPlaying) != 0 && ti->ppqPos >= 0.0) { s.ppqValid = true; s.ppq = ti->ppqPos; }
            }
        }
        const double manual = get (P_BPM);
        if (manual >= 1.0) { bpmUsed = manual; tempoSrc = 0; s.ppqValid = false; }          // a typed tempo is not the host's grid
        else if (hostTempo > 0) { bpmUsed = hostTempo; tempoSrc = 1; }
        else { bpmUsed = 120.0; tempoSrc = 2; }
        s.bpm = bpmUsed;
    }

    // ---------------------------------------------------------------- audio thread -> host
    void send (int i, float plain, float thr)
    {
        setPlain (i, plain);
        if (std::fabs (plain - sent[i]) < thr) return;
        sent[i] = plain;
        if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }
    void updateDisplay()
    {
        char t[128], tail[64] = "";
        const float vel = engine.velocity();
        char tempo[32]; std::snprintf (tempo, sizeof tempo, "%.0f BPM%s", bpmUsed, tempoSrc == 1 ? " host" : (tempoSrc == 2 ? " (default)" : ""));
        if (get (P_TFORM) > 0.5f && get (P_BYPASS) < 0.5f)
            std::snprintf (tail, sizeof tail, "  |  GATE %s %s", kRateNames[clampi ((int) get (P_TRATE), 0, 5)], kPatNames[clampi ((int) get (P_TPAT), 0, 3)]);
        const bool deck = engine.deckMode();
        const char* nm = (deck && cur != nullptr) ? cur->name : "";
        switch (engine.state())
        {
            case Engine::GRAB:
                if (deck) std::snprintf (t, sizeof t, "SCRATCH  %+.1fx  %s  %.2f s%s", (double) vel, nm, (double) engine.deckPosSec(), tail);
                else std::snprintf (t, sizeof t, "SCRATCH  %+.1fx   %.2f s back%s", (double) vel, (double) engine.behindSec(), tail);
                break;
            case Engine::SPIN: std::snprintf (t, sizeof t, "BACKSPIN  %+.1fx%s", (double) vel, tail); break;
            case Engine::PLAY:
            {
                const float ms = engine.motorSpeed();
                if (std::fabs (ms) < 0.005f) std::snprintf (t, sizeof t, "STOPPED  %.1f s behind live%s", (double) engine.behindSec(), tail);
                else if (ms < 0.f) std::snprintf (t, sizeof t, "REVERSE  %.1fx  %.1f s back%s", (double) ms, (double) engine.behindSec(), tail);
                else if (get (P_PLAY) < 0.5f) std::snprintf (t, sizeof t, "STOPPING  %.2fx%s", (double) ms, tail);
                else std::snprintf (t, sizeof t, "PITCH %+.1f %%  %.2f s behind%s", pitchPct() + (get (P_RPM) > 0.5f ? 35.0 : 0.0), (double) engine.behindSec(), tail);
                break;
            }
            case Engine::RETURN:
                if (deck) std::snprintf (t, sizeof t, "RELEASE  %+.1fx  %s%s", (double) vel, nm, tail);
                else std::snprintf (t, sizeof t, "CATCH UP  %.2f s to live%s", (double) engine.behindSec(), tail);
                break;
            case Engine::LOOP: std::snprintf (t, sizeof t, "LOOP %s  %.2f s  %s%s", kLoopNames[clampi (loopIdxActive, 0, 8)], (double) engine.loopSec(), tempo, tail); break;
            default:
                if (get (P_BYPASS) > 0.5f) std::snprintf (t, sizeof t, "BYPASS");
                else if (engine.loopFailed()) std::snprintf (t, sizeof t, deck ? "LOOP %s: play the sample first" : "LOOP %s: play some audio first", kLoopNames[clampi (loopIdxActive, 0, 8)]);
                else if (deck)
                {
                    if (! ioOk()) std::snprintf (t, sizeof t, "SAMPLE: no DJ Scratch folder on the drive");
                    else if (! engine.deckLoaded()) std::snprintf (t, sizeof t, "SAMPLE: put WAVs in DJ Scratch/Samples");
                    else std::snprintf (t, sizeof t, "%s %s  %.1f/%.1f s%s", engine.deckAtEnd() ? "END " : (get (P_PLAY) > 0.5f ? "PLAY" : "STOP"),
                                        nm, (double) engine.deckPosSec(), (double) engine.deckLenSec(), tail);
                }
                else
                {
                    const float pk = engine.inputPeak();
                    char in[24];
                    if (pk < 0.00003f) std::snprintf (in, sizeof in, "IN: no signal");
                    else std::snprintf (in, sizeof in, "IN %+.0f dB", (double) (20.f * std::log10 (pk)));
                    std::snprintf (t, sizeof t, "LIVE  %s  %s%s", in, tempo, tail);
                    if (std::fabs (speedNow() - 1.0) > 1e-6) std::snprintf (t, sizeof t, "LIVE (at now)  PITCH %+.1f %%%s", (speedNow() - 1.0) * 100.0, tail);
                }
                break;
        }
        // file messages (loaded, saved, errors) take over the line for 3 s
        const int g = ioMsgGen.load();
        if (g != seenMsgGen) { seenMsgGen = g; msgLeft = (int) (sr * 3.f); }
        if (msgLeft > 0) std::snprintf (t, sizeof t, "%s", ioMsg.get());
        // the recorder goes in front of everything
        char line[160];
        const bool wantRec = get (P_REC) > 0.5f;
        if (wantRec && ! ioOk()) std::snprintf (line, sizeof line, "REC: no DJ Scratch folder | %s", t);
        else if (recPhase == 2)
        {
            const uint32_t dropped = recDropped.load();
            std::snprintf (line, sizeof line, "REC %.1fs%s | %s", (double) recFrames.load() / (double) sr, dropped > 0 ? " (DROPOUTS)" : "", t);
        }
        else if (recPhase == 1) std::snprintf (line, sizeof line, "%s | %s", writerIdle.load() ? "REC ARMED" : "REC SAVING", t);
        else std::snprintf (line, sizeof line, "%s", t);
        if (! info.publish (line)) return;
        infoGen = (infoGen + 1) % 1000;
        send (P_INFO, (float) infoGen, 0.5f);
    }
    // ---------------------------------------------------------------- the deck's keys and springs (audio thread)
    // the latest roll key pressed wins and the others go out; releasing the active one ends the roll
    void rollKeys()
    {
        for (int k = 0; k < 4; ++k)
        {
            const bool on = get (kRollParam[k]) > 0.5f;
            if (on && ! rollWas[k])
            {
                rollActive = k;
                for (int j = 0; j < 4; ++j) if (j != k && get (kRollParam[j]) > 0.5f) { send (kRollParam[j], 0.f, 0.f); rollWas[j] = false; }
            }
            else if (! on && rollWas[k] && rollActive == k) rollActive = -1;
            rollWas[k] = get (kRollParam[k]) > 0.5f;
        }
        if (rollActive >= 0 && get (kRollParam[rollActive]) < 0.5f) rollActive = -1;
    }
    void deckControls (int n, Settings& s)
    {
        if (pending[P_BRAKE].exchange (0) > 0)                                     // BRAKE: stop now, hard
        {
            if (get (P_PLAY) > 0.5f) { braking = true; send (P_PLAY, 0.f, 0.f); }
            send (P_BRAKE, 0.f, 0.f);
        }
        if (get (P_PLAY) > 0.5f) braking = false;
        if (pending[P_PRESET].exchange (0) > 0) { send (P_PITCH, 0.f, 0.f); send (P_PFINE, 0.f, 0.f); send (P_BEND, 0.f, 0.f); send (P_PRESET, 0.f, 0.f); }
        const float b = get (P_BEND);                                              // BEND springs back once you let go of it
        if (b != lastBend) { lastBend = b; bendIdle = 0; }
        else if (b != 0.f && (bendIdle += n) > (int) (0.15f * sr)) { send (P_BEND, 0.f, 0.f); lastBend = 0.f; }
        s.speed = speedNow(); s.motorOn = get (P_PLAY) > 0.5f; s.stopSec = braking ? 0.12f : get (P_STOPT);
    }
    void requestSaveLast()
    {
        const int k = clampi ((int) get (P_LASTLEN), 0, 4);
        const int64_t written = engine.writtenFrames();
        const int64_t usable = (int64_t) engine.ringSize() - 3 * 16384;
        int64_t len = kLastBars[k] > 0 ? (int64_t) std::llround (kLastBars[k] * 4.0 * 60.0 / bpmUsed * (double) sr) : usable;
        if (len > written) len = written;
        if (kLastBars[k] > 0 && len > usable) { std::snprintf (lastLabel, sizeof lastLabel, "%s", kLastLen[k]); len = usable + 100000; }  // reported as too long
        else std::snprintf (lastLabel, sizeof lastLabel, "%s", kLastLen[k]);
        lastEnd.store (written); lastLen.store (len);
        lastGen.fetch_add (1);
    }
    // the spinning record and the input meter on the screen (~25 updates a second)
    void visuals (int n)
    {
        angle += engine.takeMotion() / (double) sr * (100.0 / 3.0 / 60.0);       // 33 1/3 rpm at 1x
        angle -= std::floor (angle);
        visualCountdown -= n;
        if (visualCountdown > 0) return;
        visualCountdown += (int) (sr / 25.f);
        send (P_SPIN, (float) angle, 0.004f);
        const float pk = engine.inputPeak();
        const float m = pk < 1e-6f ? 0.f : clampf ((20.f * std::log10 (pk) + 60.f) / 60.f, 0.f, 1.f);
        send (P_INMETER, m, 0.015f);
    }
    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        Settings s = settings();
        readHostTime (s);
        const int held = noteLast.load();
        rollKeys();
        const int roll = rollActive >= 0 ? kRollLoop[rollActive] : -1;
        const int loopIdx = held >= 0 ? held : (roll >= 0 ? roll : clampi ((int) get (P_LOOPLEN), 0, 8));
        loopIdxActive = loopIdx;
        s.loopOn = get (P_LOOP) > 0.5f || held >= 0 || roll >= 0; s.loopBeats = kLoopBeats[loopIdx];
        s.tOn = get (P_TFORM) > 0.5f; s.tStepBeats = kRateBeats[clampi ((int) get (P_TRATE), 0, 5)];
        s.tDuty = get (P_TDUTY) * 0.01f; s.tMask = kPatMask[clampi ((int) get (P_TPAT), 0, 3)];
        if (tformDirty.exchange (0)) send (P_TFORM, get (P_TFORM), 0.f);
        // taps on the trigger keys: act on them, then let the key spring back
        if (pending[P_BACKSPIN].exchange (0) > 0) { engine.triggerBackspin(); send (P_BACKSPIN, 0.f, 0.f); }
        if (pending[P_CHOP].exchange (0) > 0) { engine.triggerChop(); send (P_CHOP, 0.f, 0.f); }
        if (pending[P_CUE].exchange (0) > 0) { engine.triggerCue(); send (P_CUE, 0.f, 0.f); }
        if (pending[P_RESCAN].exchange (0) > 0) { rescanReq.store (1); send (P_RESCAN, 0.f, 0.f); }
        deckControls (n, s);
        if (float* m = nextRing.exchange (nullptr))                               // HISTORY changed: the new ring
        {
            const uint32_t nf = nextRingFrames.load();
            retiredRing.store (engine.adoptRing (m, nf));
            ringFramesNow.store (nf);
        }
        const bool recInput = get (P_RECSRC) > 0.5f;
        if (recInput) { std::memcpy (inCopy[0], inL, sizeof (float) * (size_t) n); std::memcpy (inCopy[1], inR, sizeof (float) * (size_t) n); }
        // a new record from the I/O thread: put it on the platter, hand the old one back to be freed
        if (dsio::Sample* ns = next.exchange (nullptr))
        {
            dsio::Sample* old = cur; cur = ns;
            engine.setRecord (ns->l, ns->r, ns->len);
            if (old != nullptr) retired.store (old);
        }
        engine.process (inL, inR, outL, outR, n, s);
        if (recInput) recordBlock (inCopy[0], inCopy[1], n); else recordBlock (outL, outR, n);
        if (pending[P_SAVELAST].exchange (0) > 0) { requestSaveLast(); send (P_SAVELAST, 0.f, 0.f); }
        // hand off the record: bring the platter control back to the middle so the next scratch has room both ways
        if (engine.state() != Engine::GRAB && std::fabs (s.platter - 0.5f) > 0.002f)
        {
            engine.notePlatter (0.5f);
            send (P_PLATTER, 0.5f, 0.f);
        }
        visuals (n);
        if (msgLeft > 0) msgLeft -= n;
        displayCountdown -= n;
        if (displayCountdown <= 0) { displayCountdown += (int) (sr / 15.f); updateDisplay(); }
    }
    void display (int idx, char* out, size_t max)
    {
        const ParamDef& d = kParams[idx];
        const float p = v[idx].load();
        if (idx == P_INFO) { std::snprintf (out, max, "%s", info.get()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[clampi ((int) p, 0, d.n - 1)]); return; }
        if (d.kind == K_BOOL)
        {
            if (isTrigger (idx)) { std::snprintf (out, max, "Tap"); return; }
            std::snprintf (out, max, "%s", p >= 0.5f ? "On" : "Off"); return;
        }
        switch (d.fmt)
        {
            case F_DB: std::snprintf (out, max, "%+.1f dB", (double) p); return;
            case F_SEC: std::snprintf (out, max, "%.2f s", (double) p); return;
            case F_MS: std::snprintf (out, max, p < 10.f ? "%.1f ms" : "%.0f ms", (double) p); return;
            case F_X: std::snprintf (out, max, "%.1fx", (double) p); return;
            case F_PLATTER: std::snprintf (out, max, "%+.0f", (double) ((p - 0.5f) * 200.f)); return;
            case F_BPM: if (p < 1.f) std::snprintf (out, max, "Host"); else std::snprintf (out, max, "%.0f", (double) p); return;
            case F_PCT: std::snprintf (out, max, "%.0f %%", (double) p); return;
            case F_PITCH: std::snprintf (out, max, "%+.1f %%", (double) p * kRangePct[clampi ((int) get (P_PRANGE), 0, 2)]); return;
            case F_FINE:  std::snprintf (out, max, "%+.2f %%", (double) p); return;
            case F_BEND:  std::snprintf (out, max, "%+.1f %%", (double) p * kBendPct); return;
            case F_SPIN:  std::snprintf (out, max, "%.0f deg", (double) p * 360.0); return;
            case F_METER: if (p <= 0.f) std::snprintf (out, max, "-inf dB"); else std::snprintf (out, max, "%.0f dB", (double) p * 60.0 - 60.0); return;
            case F_SAMPLE:
            {
                char nm[64]; int cnt = 0;
                const int i = clampi ((int) p, 0, kMaxFiles - 1);
                if (fileShown (i, nm, sizeof nm, &cnt)) std::snprintf (out, max, "%d/%d %s", i + 1, cnt, nm);
                else if (cnt == 0) std::snprintf (out, max, "(no WAVs)");
                else std::snprintf (out, max, "%d: (empty)", i + 1);
                return;
            }
            default: std::snprintf (out, max, "%.2f", (double) p); return;
        }
    }
    static int clampi (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }
};

// ---------------------------------------------------------------------------------------------- VST2 entry points
void processReplacing (AEffect* e, float** in, float** out, int32_t n)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += Plugin::kChunk)
    {
        const int32_t m = (n - pos) < Plugin::kChunk ? (n - pos) : Plugin::kChunk;
        p->process (in[0] + pos, in[1] + pos, out[0] + pos, out[1] + pos, m);
    }
}
void processAccumulating (AEffect* e, float** in, float** out, int32_t n)
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}
void setParameter (AEffect* e, int32_t i, float norm) { if (i >= 0 && i < P_COUNT) static_cast<Plugin*> (e->object)->setNorm (i, norm); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? static_cast<Plugin*> (e->object)->nv[i].load() : 0.f; }
intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed: if (idx < 0 || idx >= kNumPresets) return 0; copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit, 8); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[96]; p->display (idx, b, sizeof b); copyStr (ptr, b, 64); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && ! isReadout (idx)) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->srA.store (opt); p->prepareEngine (opt); } return 0;
        case effMainsChanged:     if (val) p->prepareEngine (p->sr); return 0;
        case effSetBypass:        p->setPlain (P_BYPASS, val ? 1.f : 0.f); return 1;
        case effProcessEvents:    p->midiEvents (static_cast<const VstEvents*> (ptr)); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "DJ Scratch", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "ScratchLab", 32); return 1;
        case effGetVendorVersion: return 1400;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:
            if (ptr != nullptr && (std::strcmp ((const char*) ptr, "bypass") == 0 || std::strcmp ((const char*) ptr, "receiveVstEvents") == 0
                                   || std::strcmp ((const char*) ptr, "receiveVstMidiEvent") == 0)) return 1;
            return 0;
        default: return 0;
    }
}
void initOnce() { static bool done = false; if (! done) { initParams(); done = true; } }
} // namespace

DS_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    initOnce();
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    p->startIO();
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.initialDelay = 0;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('D' << 24) | ('J' << 16) | ('S' << 8) | 'C';   // 'DJSC' = 0x444A5343
    fx.version = 1400;
    return &fx;
}
// stable parameter keys for tools/make_skin.py
DS_EXPORT const char* DS_ParamKey (int i) { initOnce(); return (i >= 0 && i < P_COUNT) ? kParams[i].key : ""; }
DS_EXPORT int DS_ParamCount() { return P_COUNT; }
DS_EXPORT const char* DS_PresetName (int i) { return (i >= 0 && i < kNumPresets) ? kPresets[i].name : ""; }
DS_EXPORT int DS_PresetCount() { return kNumPresets; }
