# DJ Scratch (MPC)

A live-input turntable for the MPC: scratch, stop, pitch and reverse whatever is coming into an MPC track, pad, submix or the
master, and sample the result to a WAV for a pad. A native **MPC OS VST2 insert effect** for Gen1 devices (MPC X, Live /
Live II, One, Key 61, Force), built on the same toolchain, installer and skin pipeline as the SP1200 plugin.

    incoming audio > history (10..60 s, always recording) > needle (the record) or loop > crossfade with the live signal
                   > transformer gate > fader > output > REC (output or input, pre-roll, threshold) > WAV on the drive

- **Transparent when idle**: bit-exact pass-through, zero latency.
- **Platter**: drag it or turn Q-Link 1; two-pole inertia, 4-point Hermite interpolation, a stopped record is silent.
- **Motor**: START/STOP with adjustable spin-up and wind-down (constant torque), BRAKE, 33/45, REVERSE; on live audio the
  record winds down, spins back up and slips (or catches up) back to live. Slipmat-style hand-off after a scratch.
- **Pitch**: +/-8/16/50 % fader, fine, spring-loaded bend, reset (varispeed, like a record; no key lock).
- **Live sampler**: REC from the output or the clean input, pre-roll, start threshold, fades / normalize; **SAVE LAST** writes
  the last 1-8 bars (MPC tempo) of the input straight from the history. 24-bit WAVs to `DJ Scratch/Recordings`.
- **Sample source**: put a WAV from `DJ Scratch/Samples` on the platter instead of the live input (motor, cue, THRU).
- **Loop roll** keys (1/4, 1/8, 1/16, 1/32) and LOOP by note value (1/32..1 bar, triplets) at the MPC tempo; **transformer**
  gate (rate, pattern, open) locked to the MPC beat; backspin, fader + chop, 17 presets, MIDI notes.
- Four screen pages (DECK, GROOVE, SAMPLER, SETUP): an original deck design with a record label that turns with the audio,
  a long pitch fader and an input meter. See `docs/skin-preview-*.png`.
- All disk access on a background thread; the audio thread never blocks.

How to use it: **`mpc/INSTALL.md`**.

## Build + install
    ./scripts/build_mpc.sh <mpc-ip>   # no GitHub: builds the ARM plugin (cross-compiler or Docker), checks it, packages, installs over SSH
    make abi32                        # 32-bit VST2 struct layout check (what the ARM MPC sees)
    make test                         # engine_test (ASan/UBSan) + host_test (VST2 interface and a scratch gesture through setParameter)
    python3 tools/make_skin.py docs   # regenerate the skin and previews (needs Pillow and `make native`)
    ./scripts/package.sh              # cross-compiles for ARM, verifies the ELF, makes dist/DJScratch-1.4.0-mpc-armv7.zip
    ./scripts/verify_arm.sh [file.so] # checks a .so against the SP1200 reference (ELF32 ARM, hard-float, libc/libm only)
./scripts/deploy.sh <mpc-ip>      # tar-over-ssh, runs install.sh
`package.sh` needs `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`) or Docker (it uses `make docker`).
`make host_test` can also write a demo: `./build/native/host_test build/native/djscratch.so demo.wav`.

## Layout
    src/scratch/Scratch.h   the engine (ring buffer, platter model, states LIVE / GRAB / SPIN / RETURN, fader)
    src/djscratch.cpp       VST2 entry points, parameter table, presets, status readout, the I/O thread (sample loading, REC)
    src/fileio.h            WAV reader (any rate, PCM/float, resampled on load), 24-bit WAV writer, fades/normalize, folder listing
    src/vst2.h              minimal VST2 ABI (no Steinberg SDK)
    tools/make_skin.py      TUI.json, Q-Links and PNGs for the MPC screen
    mpc/                    installer, uninstaller, plugin-list entry, skin, INSTALL.md
    test/                   engine_test.cpp, host_test.cpp

## Status: what is tested and what is not
Tested here, on x86: the DSP (engine_test, 103 checks, under AddressSanitizer and UBSan: scratching, the motor on live input
and on a sample, pitch, reverse, slipmat release, loop, gate, the history ring) and the plugin through a VST2 host harness
(host_test, 191 checks: parameters, presets, brake / pitch / bend controls, loop roll keys, the record turning with the
motor and with the hand (touch / Q-Link), the meter read-out, host
blocks up to 4096, loading a 48 kHz WAV at 44.1 kHz, REC takes compared sample-for-sample, input source with pre-roll and
threshold, normalize, SAVE LAST), the I/O thread under ThreadSanitizer, and the installer in a fake MPC root.

**Not tested on a device**: the ARM build (no ARM compiler where this was written), CPU load, how the MPC's touch drag maps to
the PLATTER value (set THROW to taste), whether the MPC redraws the plugin's read-outs (the turning record, the meter, the
status line, keys that spring back) when the plugin changes them, whether it reports tempo and beat position to an insert
(the plugin falls back to 120 BPM or the Tempo control), whether it sends MIDI notes to an insert, the `/media/az01-internal`
path from inside the MPC process (the plugin falls back to `/sdcard`), and drive write speed while recording (the 11 s
buffer covers stalls). The skin follows the SP1200 skin's proven rules; the big platter zone, the 3-piece pitch fader and the
3-piece meter are new.
