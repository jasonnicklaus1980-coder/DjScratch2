#!/usr/bin/env python3
"""Generate the DJ Scratch MPC screen skin (same skin pipeline and MPC rules as the SP1200 skin).

An original ScratchLab direct-drive deck design. Four pages (MPC screen tabs):
  DECK     the turntable: the big platter is a touch zone bound to PLATTER (drag on it, or turn Q-Link 1); the record label
           turns with the audio (bound to the plugin's Record Angle read-out); START-STOP, BRAKE, REVERSE and 45 on the
           plinth; a long PITCH fader with reset and range; scratch keys, LOOP ROLL keys (1/4 1/8 1/16 1/32), the
           TRANSFORMER (on, rate, pattern, open), input meter and status on the right
  GROOVE   LOOP (key + note value + tempo) and TRANSFORMER (key + rate, open %, pattern); a printed legend of the MIDI note map
  SAMPLER  REC and SAVE LAST with their settings (source, pre-roll, start, after, length, history); the SAMPLE source deck
  SETUP    release mode, backspin, fader, platter feel, output, bypass, motor (start / stop time, fine pitch, bend, 45)
Every control is bound to "Parameter N"; the indices come from the built plugin (DS_ParamKey), so run `make native` first.
MPC rules (proven on an MPC X with the SP1200 skin): square filmstrip frames, 128 frames, numFrames = last frame index (127),
pieces at most 84 px wide, the knob fully inside its parent box.  Requires Pillow.
Usage: python3 tools/make_skin.py [preview-dir]
"""
import ctypes, json, math, os, random, shutil, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIN_NAME = "ScratchLab - VST - DJ Scratch"          # MPC looks for "<manufacturer> - VST - <plugin name>"
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", SKIN_NAME)
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
W, H = 1280, 628
FRAMES, NUMFRAMES, SS = 128, 127, 4

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
def font(size, name="DejaVuSans-Bold.ttf"):
    for d in FONT_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

# ---------- palette: gunmetal plinth, machined steel, amber light ----------
BODY    = (24, 26, 31)           # panel
PLINTH  = (36, 40, 48)           # gunmetal plinth
PLINTH_EDGE = (120, 128, 140)
STRIP   = (178, 184, 192)        # brushed steel strips
INK     = (18, 18, 20)
PRINT   = (232, 233, 236)
PRINT_DIM = (150, 156, 168)
RULE    = (120, 128, 140)
AMBER   = (255, 168, 40)
KEYFACE, KEYFACE_DN = (44, 47, 54), (30, 32, 37)
LCD_BG  = (12, 14, 16)
LCD_TXT = (255, 168, 40)
FOCUS_COL, LCD_COL, VALUE_COL = "ffffa828", "ffffa828", "ffffffff"

def rgba(c, a=255): return (c[0], c[1], c[2], a)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def text_c(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)
def spaced(s, n=1): return (" " * n).join(s)

# ---------- keys: a rubber key with a steel bezel and an amber LED bar ----------
KEY_W, KEY_H = 64, 66
BIG_W = 112
def key_image(on, w=KEY_W, h=KEY_H):
    s = SS
    im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w * s / 2; kw, kt, kb = (w / 2 - 13) * s, 16 * s, 46 * s
    lw, lh, ly = min(14, w / 2 - 18) * s, 2.5 * s, 7 * s
    if on:
        g = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).rounded_rectangle([cx - lw - 4 * s, ly - 6 * s, cx + lw + 4 * s, ly + 6 * s], radius=5 * s, fill=(255, 150, 20, 150))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(3 * s))); d = ImageDraw.Draw(im)
    d.rounded_rectangle([cx - lw, ly - lh, cx + lw, ly + lh], radius=2 * s, fill=rgba(AMBER if on else (84, 60, 30)))
    d.rounded_rectangle([cx - kw + 2 * s, kt + 3 * s, cx + kw + 2 * s, kb + 3 * s], radius=3 * s, fill=(0, 0, 0, 120))
    off = 2 * s if on else 0
    face = KEYFACE_DN if on else KEYFACE
    d.rounded_rectangle([cx - kw - 2 * s, kt + off - 2 * s, cx + kw + 2 * s, kb + off + 2 * s], radius=4 * s, fill=rgba((150, 156, 166)))
    d.rounded_rectangle([cx - kw, kt + off, cx + kw, kb + off], radius=3 * s, fill=rgba(face))
    for k in range(6):
        yy = kt + off + (5 + k * 4) * s
        d.line([cx - kw + 5 * s, yy, cx + kw - 5 * s, yy], fill=rgba(mix(face, (0, 0, 0), 0.35)), width=s)
    d.line([cx - kw + 3 * s, kt + off + s, cx + kw - 3 * s, kt + off + s], fill=rgba(mix(face, (255, 255, 255), 0.18)), width=s)
    return im.resize((w, h), Image.LANCZOS)

# ---------- faders (filmstrips of stacked 84 px pieces of one drawing) ----------
FW, FY, FPIECE = 76, 24, 84
def fader_frame(t, height, cap=(120, 124, 132), centre_mark=False):
    s = SS; w, h = FW * s, height * s
    t0, t1 = 24, height - 24
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w / 2
    d.rounded_rectangle([cx - 4 * s, t0 * s - 12 * s, cx + 4 * s, t1 * s + 12 * s], radius=4 * s, fill=rgba((4, 4, 5)))
    d.line([cx, t0 * s - 8 * s, cx, t1 * s + 8 * s], fill=rgba((54, 56, 62)), width=2 * s)
    if centre_mark:
        cm = (t0 + t1) / 2 * s
        d.line([cx - 12 * s, cm, cx + 12 * s, cm], fill=rgba(AMBER), width=2 * s)
    cy = (t1 + (t0 - t1) * t) * s
    cw, ch = 28 * s, 18 * s
    sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([cx - cw + 2 * s, cy - ch + 6 * s, cx + cw + 2 * s, cy + ch + 6 * s], radius=4 * s, fill=(0, 0, 0, 160))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(4 * s))); d = ImageDraw.Draw(im)
    capim = Image.new("RGBA", (w, h), (0, 0, 0, 0)); cd = ImageDraw.Draw(capim)
    for yy in range(int(cy - ch), int(cy + ch) + 1):
        k = (yy - (cy - ch)) / (2 * ch)
        col = mix(cap, mix(cap, (0, 0, 0), 0.6), k)
        if int((yy - (cy - ch)) / (3 * s)) % 2 == 1: col = mix(col, (0, 0, 0), 0.22)
        cd.line([cx - cw, yy, cx + cw, yy], fill=rgba(col))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([cx - cw, cy - ch, cx + cw, cy + ch], radius=4 * s, fill=255)
    im.paste(capim, (0, 0), mask); d = ImageDraw.Draw(im)
    d.rounded_rectangle([cx - cw, cy - ch, cx + cw, cy + ch], radius=4 * s, outline=rgba((176, 182, 192)), width=s)
    d.rectangle([cx - cw + 3 * s, cy - 1.5 * s, cx + cw - 3 * s, cy + 1.5 * s], fill=rgba(AMBER if centre_mark else PRINT))
    return im.resize((FW, height), Image.LANCZOS)
def fader_pieces(npieces, **kw):
    height = npieces * FPIECE
    strips = [Image.new("RGBA", (FPIECE, FPIECE * FRAMES), (0, 0, 0, 0)) for _ in range(npieces)]
    x0 = (FPIECE - FW) // 2
    for f in range(FRAMES):
        fr = fader_frame(f / (FRAMES - 1), height, **kw)
        for k in range(npieces): strips[k].paste(fr.crop((0, k * FPIECE, FW, (k + 1) * FPIECE)), (x0, f * FPIECE))
    return strips

# ---------- the input meter: 3 square 42 px pieces side by side, 15 segments ----------
MP, MN = 42, 3
def meter_strips():
    strips = [Image.new("RGBA", (MP, MP * FRAMES), (0, 0, 0, 0)) for _ in range(MN)]
    segs = 15; wtot = MP * MN
    for f in range(FRAMES):
        lvl = f / (FRAMES - 1)
        fr = Image.new("RGBA", (wtot * SS, MP * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(fr)
        for k in range(segs):
            x0 = (4 + k * (wtot - 8) / segs) * SS; x1 = x0 + ((wtot - 8) / segs - 2) * SS
            lit = (k + 0.5) / segs <= lvl
            col = (90, 200, 120) if k < 10 else (AMBER if k < 13 else (230, 60, 50))
            d.rounded_rectangle([x0, 12 * SS, x1, 30 * SS], radius=SS, fill=rgba(col if lit else mix(col, (0, 0, 0), 0.8)))
        fr = fr.resize((wtot, MP), Image.LANCZOS)
        for k in range(MN): strips[k].paste(fr.crop((k * MP, 0, (k + 1) * MP, MP)), (0, f * MP))
    return strips

# ---------- the record label: turns with the audio (2 x 2 tiling of one 168 px drawing, a full turn over the frames) ----------
REC, PIECE = 168, 84
def record_frame(angle):
    s = 3; n = REC * s; c = n / 2
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    R = 82 * s
    d.ellipse([c - R, c - R, c + R, c + R], fill=rgba((16, 16, 18)))
    for rr in range(80, 70, -3): d.ellipse([c - rr * s, c - rr * s, c + rr * s, c + rr * s], outline=rgba((34, 34, 38)), width=s)
    r = 68 * s
    box = [c - r, c - r, c + r, c + r]
    d.ellipse(box, fill=rgba((232, 226, 210)))                                  # cream label
    d.pieslice(box, angle - 100, angle - 20, fill=rgba(AMBER))                   # an amber sector so the rotation reads
    d.pieslice(box, angle + 80, angle + 160, fill=rgba((44, 52, 70)))            # and a navy one
    d.ellipse([c - 34 * s, c - 34 * s, c + 34 * s, c + 34 * s], fill=rgba((26, 28, 34)))
    t = Image.new("RGBA", (96 * s, 24 * s), (0, 0, 0, 0)); td = ImageDraw.Draw(t)
    text_c(td, 48 * s, 12 * s, "SCRATCHLAB", font(9 * s), rgba(AMBER)); t = t.rotate(-angle, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(t, (int(c - t.size[0] / 2), int(c - t.size[1] / 2)))
    a = math.radians(angle)
    x, y = c + 76 * s * math.sin(a), c - 76 * s * math.cos(a)
    d.ellipse([x - 3 * s, y - 3 * s, x + 3 * s, y + 3 * s], fill=rgba((255, 255, 255)))                  # cue marker on the vinyl
    d.ellipse([c - 5 * s, c - 5 * s, c + 5 * s, c + 5 * s], fill=rgba((200, 202, 208)))                  # spindle
    d.ellipse([c - 2 * s, c - 2 * s, c + 2 * s, c + 2 * s], fill=rgba((60, 60, 66)))
    return im.resize((REC, REC), Image.LANCZOS)
def record_strips():
    strips = [Image.new("RGBA", (PIECE, PIECE * FRAMES), (0, 0, 0, 0)) for _ in range(4)]
    for f in range(FRAMES):
        fr = record_frame(f / FRAMES * 360.0)                                    # Record Angle 0..1 = one full turn
        for k in range(4):
            gx, gy = k % 2, k // 2
            strips[k].paste(fr.crop((gx * PIECE, gy * PIECE, gx * PIECE + PIECE, gy * PIECE + PIECE)), (0, f * PIECE))
    return strips

# ---------- TUI.json (same schema as the SP1200 / GlueBus skins) ----------
NOREMAP = {"version": 1, "map": []}
def bounds(b, focus="No", show="Show", visible="Always"):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": show, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": " ".join(str(int(v)) for v in b), "additionalInvalidatingHandles": []}
def comp(name, typ, data, b, remap=None):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": remap or NOREMAP, "bounds": b}
def action(on, handler, extra=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": extra, "handle remapping": NOREMAP}
def bgdata(col="0"): return {"version": 1, "focussed": {"version": 1, "colour": col, "image": ""}, "unfocussed": {"version": 1, "colour": col, "image": ""}}
def definition(actions, parts, bgcol="0", ignore=False):
    return {"version": 4, "actions": actions, "backgroundData": bgdata(bgcol), "ignoreMousePresses": ignore,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": parts}
def label(kind, h, colour, b, case="Original", name=None):
    return comp(name or kind, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web", "style": "SemiBold", "height": float(h)},
                "colour": colour, "justification": "horizontallyCentred verticallyCentred", "case": case}, "type": kind, "handleName": "Data"}, bounds(b))
def focus(b):
    return comp("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": FOCUS_COL, "backgroundInset": 2.0, "outlineThickness": 2.0},
                bounds(b, visible="WhenFocussed"))

# ---------- parameter indices from the built plugin ----------
LIB = os.path.join(ROOT, "build", "native", "djscratch.so")
def load_keys():
    lib = ctypes.CDLL(LIB)
    lib.DS_ParamKey.restype = ctypes.c_char_p; lib.DS_ParamKey.argtypes = [ctypes.c_int]
    lib.DS_ParamCount.restype = ctypes.c_int
    return {lib.DS_ParamKey(i).decode(): i for i in range(lib.DS_ParamCount())}
P = load_keys()

# ---------- layout ----------
TABS = ["DECK", "GROOVE", "SAMPLER", "SETUP"]
BG_ITEMS = {t: [] for t in TABS}
PLACED = {t: [] for t in TABS}
DEFS, IMAGES = {}, {}
def img(name, im): IMAGES[name] = im; return name
def defn(key, value): DEFS.setdefault(key, value); return key
def place(tab, name, dkey, param, x, y, w, h, kind, extra=None, touch=True):
    PLACED[tab].append(dict(name=name, dkey=dkey, param=param, x=x, y=y, w=w, h=h, kind=kind, extra=extra, touch=touch))

DRAG = "ds_drag.png"
def drag_strip(sq=16): return Image.new("RGBA", (sq, sq * FRAMES), (0, 0, 0, 0))
CTRL = lambda: [action("Mouse Down", "Q-Link"), action("Double Click", "Show Overlay", "knob overlay"), action("Enter Pressed", "Show Overlay", "knob overlay")]
def drag_knob(w, h, orient="Vertical"):
    img(DRAG, drag_strip())
    return comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": DRAG, "numFrames": NUMFRAMES, "invert": False,
                "dragOrientation": orient, "handleName": "Data"}, bounds((0, 0, w, h)))
def d_box(w, h, fs=17):
    key = f"dsBox{w}x{h}_{fs}"
    return defn(key, definition(CTRL(), [drag_knob(w, h), label("Value", fs, LCD_COL, (0, 0, w, h), case="Upper Case"), focus((0, 0, w, h))]))
def d_text(w, h, fs, col=LCD_COL):
    return defn(f"dsText{w}x{h}_{fs}", definition([], [label("Value", fs, col, (0, 0, w, h))], ignore=True))
def d_zone(w, h):
    return defn(f"dsZone{w}x{h}", definition([action("Mouse Down", "Q-Link")], [drag_knob(w, h)]))

def section(tab, x0, x1, y, title): BG_ITEMS[tab].append(("section", x0, x1, y, title))
def box(tab, name, key, x, y, w=186, h=44, caption=None, fs=17):
    place(tab, name, d_box(w, h, fs), P[key], x, y, w, h, "box")
    BG_ITEMS[tab].append(("lcd", x, y, w, h, caption))
def text(tab, name, key, x, y, w, h, fs=15):
    place(tab, name, d_text(w, h, fs), P[key], x, y, w, h, "text", fs, touch=False)
def keycap(tab, name, key, x, y, cap, big=False):
    place(tab, name, "dsBigKey" if big else "dsKey", P[key], x, y, BIG_W if big else KEY_W, KEY_H, "bigkey" if big else "key")
    BG_ITEMS[tab].append(("cap", x + (BIG_W if big else KEY_W) / 2, y + KEY_H + 10, cap))
def meter(tab, x, y, cap="INPUT"):
    place(tab, "Input Level", "dsMeter", P["inmeter"], x, y, MP * MN, MP, "meter", touch=False)
    BG_ITEMS[tab].append(("meterbg", x, y, cap))
def status(tab, x, y, w, h, fs=20):
    BG_ITEMS[tab].append(("lcd", x, y, w, h, None))
    text(tab, "Status", "info", x + 6, y + 4, w - 12, h - 8, fs)

# ---------- shared component definitions ----------
img("ds_key_on.png", key_image(True)); img("ds_key_off.png", key_image(False))
img("ds_bigkey_on.png", key_image(True, BIG_W)); img("ds_bigkey_off.png", key_image(False, BIG_W))
def keydef(name, on, off, w):
    defn(name, definition([action("Mouse Down", "Q-Link"), action("Enter Pressed", "Toggle Switch")], [
        focus((0, 0, w, KEY_H)),
        comp("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": 1,
             "numButtonsInGroup": 1, "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((0, 0, w, KEY_H)))]))
keydef("dsKey", "ds_key_on.png", "ds_key_off.png", KEY_W)
keydef("dsBigKey", "ds_bigkey_on.png", "ds_bigkey_off.png", BIG_W)
for k, st in enumerate(record_strips()): img(f"ds_record{k}.png", st)
rknob = lambda k: comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_record{k}.png", "numFrames": NUMFRAMES,
                       "invert": False, "dragOrientation": "Vertical", "handleName": "Data"}, bounds(((k % 2) * PIECE, (k // 2) * PIECE, PIECE, PIECE)))
defn("dsRecord", definition([], [rknob(k) for k in range(4)], ignore=True))
for k, st in enumerate(meter_strips()): img(f"ds_meter{k}.png", st)
defn("dsMeter", definition([], [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_meter{k}.png", "numFrames": NUMFRAMES,
     "invert": False, "dragOrientation": "Horizontal", "handleName": "Data"}, bounds((k * MP, 0, MP, MP))) for k in range(MN)], ignore=True))
NPITCH = 3; PSW = 100; PSH = FY + NPITCH * FPIECE
for k, st in enumerate(fader_pieces(NPITCH, cap=(150, 154, 162), centre_mark=True)): img(f"ds_pitch{k}.png", st)
pknob = lambda k: comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_pitch{k}.png", "numFrames": NUMFRAMES,
                       "invert": False, "dragOrientation": "Vertical", "handleName": "Data"}, bounds(((PSW - FPIECE) // 2, FY + k * FPIECE, FPIECE, FPIECE)))
defn("dsPitch", definition(CTRL(), [focus((0, 0, PSW, PSH))] + [pknob(k) for k in range(NPITCH)] + [
     label("Value", 15, LCD_COL, (0, 0, PSW, 22), case="Upper Case")]))

# ================================================================= DECK page
T = "DECK"
PCX, PCY, PR = 272, 300, 206                 # platter centre and radius
PLX0, PLY0, PLX1, PLY1 = 22, 50, 800, 598    # plinth
place(T, "Scratch Zone", d_zone(440, 440), P["platter"], PCX - 220, PCY - 220, 440, 440, "zone")
place(T, "Record", "dsRecord", P["spin"], PCX - REC // 2, PCY - REC // 2, REC, REC, "record", touch=False)
keycap(T, "Start Stop", "play", 40, 514, "START  STOP", big=True)
keycap(T, "Brake", "brake", 172, 514, "BRAKE")
keycap(T, "Reverse", "reverse", 250, 514, "REVERSE")
keycap(T, "45", "rpm", 328, 514, "45 RPM")
PFX, PFY = 690, 262                          # pitch fader
place(T, "Pitch", "dsPitch", P["pitch"], PFX, PFY, PSW, PSH, "pitch")
keycap(T, "Pitch Reset", "pitchreset", 594, 514, "RESET")
box(T, "Pitch Range", "prange", 650, 176, w=140, h=40, caption="Pitch Range", fs=14)
RX = 830
KX = [RX + i * 106 for i in range(4)]
meter(T, 652, 100)
section(T, RX, 1256, 50, "Scratch")
keycap(T, "Hold", "hold", KX[0], 80, "HOLD")
keycap(T, "Auto Grab", "auto", KX[1], 80, "AUTO")
keycap(T, "Backspin", "backspin", KX[2], 80, "BACKSPIN")
keycap(T, "Chop", "chop", KX[3], 80, "CHOP")
keycap(T, "Fader", "fader", KX[0], 160, "FADER")
keycap(T, "Loop", "loop", KX[1], 160, "LOOP")
keycap(T, "Record", "rec", KX[2], 160, "REC")
section(T, RX, 1256, 260, "Loop roll  (1/4 . 1/8 . 1/16 . 1/32)")
keycap(T, "Loop 1/4", "roll4", KX[0], 290, "1/4")
keycap(T, "Loop 1/8", "roll8", KX[1], 290, "1/8")
keycap(T, "Loop 1/16", "roll16", KX[2], 290, "1/16")
keycap(T, "Loop 1/32", "roll32", KX[3], 290, "1/32")
section(T, RX, 1256, 388, "Transformer  (rate / pattern / open)")
keycap(T, "Transformer", "tform", RX, 418, "ON")
box(T, "Gate Rate", "trate", RX + 84, 428, w=104, h=40, fs=15)
box(T, "Gate Pattern", "tpat", RX + 200, 428, w=132, h=40, fs=14)
box(T, "Gate Open", "tduty", RX + 344, 428, w=82, h=40, fs=15)
status(T, RX, 516, 426, 44, fs=15)

# ================================================================= GROOVE page
T = "GROOVE"
section(T, 24, 620, 54, "Loop  (repeats the last note value)")
keycap(T, "Loop", "loop", 24, 92, "LOOP")
box(T, "Loop Length", "looplen", 120, 120, caption="Note Value")
box(T, "Tempo", "bpm", 326, 120, caption="Tempo (Host = follow MPC)")
section(T, 660, 1256, 54, "Transformer  (tempo-synced gate)")
keycap(T, "Transformer", "tform", 660, 92, "ON")
box(T, "Gate Rate", "trate", 756, 120, w=150, caption="Rate")
box(T, "Gate Open", "tduty", 920, 120, w=150, caption="Open")
box(T, "Gate Pattern", "tpat", 1084, 120, w=172, caption="Pattern")
section(T, 24, 620, 230, "Play it from notes  (any octave, hold)")
BG_ITEMS[T].append(("legend", 24, 276, [
    "C 1/32     C# 1/16T     D 1/16",
    "D# 1/8T    E 1/8        F 1/4T",
    "F# 1/4     G 1/2        G# 1 bar",
    "A backspin    A# chop    B transformer on/off"]))
section(T, 660, 1256, 230, "Platter")
box(T, "Throw", "throw", 660, 296, caption="Throw")
box(T, "Inertia", "inertia", 865, 296, caption="Inertia")
section(T, 24, 1256, 406, "Status")
status(T, 24, 450, 1232, 64)

# ================================================================= SAMPLER page
T = "SAMPLER"
section(T, 24, 1256, 54, "Live sampler  (saves to Internal > DJ Scratch > Recordings)")
keycap(T, "Record", "rec", 24, 92, "REC")
keycap(T, "Save Last", "savelast", 100, 92, "SAVE LAST")
SBX = 196
box(T, "Rec Source", "recsrc", SBX, 120, w=158, caption="Rec Source", fs=15)
box(T, "Pre-roll", "preroll", SBX + 176, 120, w=158, caption="Pre-roll", fs=15)
box(T, "Rec Start", "thresh", SBX + 352, 120, w=158, caption="Rec Start", fs=15)
box(T, "After Rec", "after", SBX + 528, 120, w=158, caption="After Rec", fs=15)
box(T, "Save Length", "lastlen", SBX + 704, 120, w=158, caption="Save Last", fs=15)
box(T, "History", "buflen", SBX + 880, 120, w=170, caption="History", fs=15)
section(T, 24, 1256, 230, "Sample deck  (Source = Sample: scratch a WAV from DJ Scratch > Samples)")
box(T, "Source", "source", 24, 296, w=190, caption="Source")
box(T, "Sample", "sample", 230, 296, w=470, caption="Sample  (turn to pick)")
keycap(T, "Cue", "cue", 724, 268, "CUE")
keycap(T, "Input Thru", "thru", 802, 268, "THRU")
keycap(T, "Rescan", "rescan", 880, 268, "RESCAN")
meter(T, 1110, 292)
section(T, 24, 1256, 406, "Status")
status(T, 24, 450, 1232, 64)

# ================================================================= SETUP page
T = "SETUP"
section(T, 24, 620, 52, "Release")
box(T, "Return", "return", 24, 112, caption="Release (Catch up = vinyl)")
box(T, "Catch-up Speed", "catch", 229, 112, caption="Catch-up Speed")
keycap(T, "Bypass", "bypass", 470, 86, "BYPASS")
section(T, 660, 1256, 52, "Backspin")
box(T, "Spin Speed", "spinspeed", 660, 112, caption="Spin Speed")
box(T, "Spin Time", "spintime", 865, 112, caption="Spin Time")
section(T, 24, 620, 182, "Fader")
box(T, "Chop Length", "chopms", 24, 242, caption="Chop Length")
box(T, "Fader Time", "cutms", 229, 242, caption="Fader Time")
box(T, "Output", "output", 434, 242, caption="Output")
section(T, 660, 1256, 182, "Platter")
box(T, "Throw", "throw", 660, 242, caption="Throw")
box(T, "Inertia", "inertia", 865, 242, caption="Inertia")
box(T, "Auto Release", "release", 1070, 242, caption="Auto Release")
section(T, 24, 1256, 312, "Motor  (how the deck starts and stops; fine pitch and bend)")
box(T, "Start Time", "startt", 24, 372, caption="Start Time")
box(T, "Stop Time", "stopt", 229, 372, caption="Stop Time")
box(T, "Fine Pitch", "pfine", 434, 372, caption="Fine Pitch")
box(T, "Bend", "bend", 639, 372, caption="Bend (springs back)")
keycap(T, "45", "rpm", 860, 346, "45 RPM")
section(T, 24, 1256, 442, "Status")
status(T, 24, 480, 1232, 60)

QL = {
    "DECK": ["platter", "pitch", "bend", "play", "brake", "backspin", "reverse", "loop", "looplen", "tform", "trate", "rec"],
    "GROOVE": ["loop", "looplen", "bpm", "tform", "trate", "tduty", "tpat", "hold", "backspin", "chop", "fader", "output"],
    "SAMPLER": ["platter", "rec", "savelast", "lastlen", "recsrc", "preroll", "thresh", "after", "source", "sample", "cue", "thru"],
    "SETUP": ["startt", "stopt", "pfine", "bend", "return", "catch", "spinspeed", "spintime", "throw", "inertia", "output", "bypass"],
}

# ---------- backgrounds ----------
def brushed(w, h, base, seed, amp=5, vertical=False):
    random.seed(seed)
    im = Image.new("RGB", (w, h), base); d = ImageDraw.Draw(im)
    for i in range(h if not vertical else w):
        n = random.randint(-amp, amp); c = (base[0] + n, base[1] + n, base[2] + n)
        if vertical: d.line([i, 0, i, h], fill=c)
        else: d.line([0, i, w, i], fill=c)
    return im

def panel_bg(title_right):
    random.seed(7)
    im = Image.new("RGB", (W, H), BODY); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-2, 2); px[x, y] = (BODY[0] + n, BODY[1] + n, BODY[2] + n)
    d = ImageDraw.Draw(im)
    for (y0, y1) in ((0, 40), (H - 26, H)):
        im.paste(brushed(W, y1 - y0, STRIP, 5 + y0, amp=6), (0, y0))
    d = ImageDraw.Draw(im)
    d.line([0, 40, W, 40], fill=(90, 94, 102), width=2); d.line([0, H - 26, W, H - 26], fill=(90, 94, 102), width=2)
    d.line([0, 41, W, 41], fill=(226, 230, 236), width=1)
    d.text((24, 6), "DJ SCRATCH", font=font(24), fill=INK)
    d.text((196, 15), spaced("SCRATCHLAB  DD-ONE  LIVE  SAMPLING  DECK", 2), font=font(9), fill=INK)
    tw = d.textlength(spaced(title_right), font=font(13)); d.text((W - 24 - tw, 13), spaced(title_right), font=font(13), fill=INK)
    d.text((24, H - 20), "ScratchLab", font=font(12, "DejaVuSans.ttf"), fill=INK)
    return im, d

def deck(im):
    """The ScratchLab DD-One: gunmetal plinth with a steel edge, a machined platter with a knurled rim and an amber light ring,
    rubber mat, vinyl, a straight tonearm, and the pitch fader well. The record label (a filmstrip) turns in the middle."""
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = PLX0, PLY0, PLX1, PLY1
    d.rounded_rectangle([x0 - 3, y0 - 3, x1 + 3, y1 + 3], radius=18, fill=PLINTH_EDGE)
    d.rounded_rectangle([x0 - 1, y0 - 1, x1 + 1, y1 + 1], radius=16, fill=(64, 68, 78))
    top = brushed(x1 - x0, y1 - y0, PLINTH, 21, amp=2, vertical=True)
    mask = Image.new("L", top.size, 0); ImageDraw.Draw(mask).rounded_rectangle([0, 0, top.size[0] - 1, top.size[1] - 1], radius=15, fill=255)
    im.paste(top, (x0, y0), mask); d = ImageDraw.Draw(im)
    # amber light ring around the platter well
    S = 3; N = 2 * PR + 60; n = N * S; c = n / 2
    glow = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([c - (PR + 14) * S, c - (PR + 14) * S, c + (PR + 14) * S, c + (PR + 14) * S], outline=(255, 150, 30, 200), width=5 * S)
    glow = glow.filter(ImageFilter.GaussianBlur(5 * S))
    pl = Image.new("RGBA", (n, n), (0, 0, 0, 0)); pl.alpha_composite(glow); pd = ImageDraw.Draw(pl)
    pd.ellipse([c - (PR + 8) * S, c - (PR + 8) * S, c + (PR + 8) * S, c + (PR + 8) * S], fill=(10, 11, 13, 255))                 # well
    R = PR * S
    for k in range(PR, PR - 22, -1):                                                            # machined rim with a soft light falloff
        t = (PR - k) / 22.0; col = mix((206, 210, 218), (110, 114, 124), t)
        pd.ellipse([c - k * S, c - k * S, c + k * S, c + k * S], fill=rgba(col))
    for j in range(240):                                                                        # knurling on the rim edge
        a = 2 * math.pi * j / 240
        xa, ya = c + (PR - 2) * S * math.cos(a), c + (PR - 2) * S * math.sin(a)
        xb, yb = c + (PR - 9) * S * math.cos(a), c + (PR - 9) * S * math.sin(a)
        pd.line([xa, ya, xb, yb], fill=rgba((96, 100, 110)), width=S)
    M = (PR - 22) * S
    pd.ellipse([c - M, c - M, c + M, c + M], fill=rgba((40, 41, 46)))                           # rubber mat
    random.seed(4)
    for rr in range(PR - 26, 100, -6):
        g = random.randint(36, 52); pd.ellipse([c - rr * S, c - rr * S, c + rr * S, c + rr * S], outline=rgba((g, g, g + 3)), width=1)
    V = (PR - 30) * S
    pd.ellipse([c - V - 2 * S, c - V - 2 * S, c + V + 2 * S, c + V + 2 * S], fill=rgba((6, 6, 7)))
    pd.ellipse([c - V, c - V, c + V, c + V], fill=rgba((13, 13, 15)))                             # vinyl
    r = V - 4 * S
    while r > 88 * S:
        g = random.randint(18, 34); pd.ellipse([c - r, c - r, c + r, c + r], outline=rgba((g, g, g + 2)), width=1); r -= random.choice([2, 3, 4]) * S // 2 or 1
    sheen = Image.new("RGBA", (n, n), (0, 0, 0, 0)); sd = ImageDraw.Draw(sheen)
    for a0 in (-58, 122): sd.pieslice([c - V, c - V, c + V, c + V], a0, a0 + 24, fill=(255, 255, 255, 34))
    sheen = sheen.filter(ImageFilter.GaussianBlur(10 * S))
    hole = Image.new("L", (n, n), 0); ImageDraw.Draw(hole).ellipse([c - V, c - V, c + V, c + V], fill=255)
    sheen.putalpha(Image.composite(sheen.getchannel("A"), Image.new("L", (n, n), 0), hole)); pl.alpha_composite(sheen)
    pl = pl.resize((N, N), Image.LANCZOS)
    im.paste(pl, (PCX - N // 2, PCY - N // 2), pl)
    d = ImageDraw.Draw(im)
    d.ellipse([PCX - 86, PCY - 86, PCX + 86, PCY + 86], fill=(12, 12, 14))
    # straight tonearm: square counterweight, gimbal base, straight tube, headshell resting on the record's edge
    ax, ay = 560, 108
    d.rectangle([ax - 16, ay - 50, ax + 16, ay - 20], fill=(58, 62, 70), outline=(170, 176, 186), width=2)
    for k in range(4): d.line([ax - 14, ay - 44 + k * 7, ax + 14, ay - 44 + k * 7], fill=(36, 38, 44), width=1)
    d.rounded_rectangle([ax - 26, ay - 26, ax + 26, ay + 26], radius=8, fill=(44, 47, 54), outline=(170, 176, 186), width=3)
    d.ellipse([ax - 13, ay - 13, ax + 13, ay + 13], fill=(130, 134, 144)); d.ellipse([ax - 5, ay - 5, ax + 5, ay + 5], fill=(30, 31, 34))
    ex, ey = 498, 392
    d.line([ax, ay, ex, ey], fill=(26, 27, 30), width=10); d.line([ax - 1, ay, ex - 1, ey], fill=(186, 190, 198), width=4)
    d.polygon([(ex - 14, ey - 4), (ex + 10, ey - 8), (ex + 6, ey + 26), (ex - 16, ey + 22)], fill=(48, 50, 56), outline=(170, 176, 186))
    d.rectangle([ex - 8, ey + 22, ex + 2, ey + 30], fill=(AMBER[0], AMBER[1], AMBER[2]))
    # pitch fader well and scale (+ at the top)
    d.rounded_rectangle([PFX - 4, PFY - 6, PFX + PSW + 4, PFY + PSH + 6], radius=8, fill=(20, 22, 26), outline=(90, 96, 106), width=2)
    ty0, ty1 = PFY + FY + 24, PFY + FY + NPITCH * FPIECE - 24
    for j in range(17):
        y = ty0 + (ty1 - ty0) * j / 16; big = j in (0, 8, 16)
        col = AMBER if j == 8 else mix(PLINTH, PRINT, 0.75 if big else 0.4)
        d.line([PFX - 18, y, PFX - (6 if big else 10), y], fill=col, width=2 if big else 1)
    d.text((PFX - 26, ty0 - 8), "+", font=font(15), fill=PRINT)
    d.text((PFX - 24, ty1 - 10), "-", font=font(15), fill=PRINT)
    text_c(d, PFX + PSW / 2, PFY + PSH + 22, "PITCH", font(13, "DejaVuSans.ttf"), PRINT)
    d.text((44, 470), "DRAG THE RECORD", font=font(11, "DejaVuSans.ttf"), fill=PRINT_DIM)
    d.text((44, 62), "DD-ONE", font=font(14), fill=PRINT_DIM)

def background(tab):
    im, d = panel_bg(tab)
    if tab == "DECK": deck(im); d = ImageDraw.Draw(im)
    for item in BG_ITEMS[tab]:
        k = item[0]
        if k == "section":
            _, x0, x1, y, title = item
            d.text((x0, y), title, font=font(17, "DejaVuSans.ttf"), fill=PRINT)
            d.line([x0, y + 26, x1, y + 26], fill=RULE, width=2)
        elif k == "lcd":
            _, x, y, w, hh, cap = item
            d.rounded_rectangle([x - 5, y - 5, x + w + 5, y + hh + 5], radius=5, fill=(150, 156, 166))
            d.rounded_rectangle([x - 3, y - 3, x + w + 3, y + hh + 3], radius=4, fill=(8, 9, 11))
            d.rectangle([x, y, x + w, y + hh], fill=LCD_BG)
            if cap: d.text((x, y - 26), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "meterbg":
            _, x, y, cap = item
            d.rounded_rectangle([x - 4, y - 2, x + MP * MN + 4, y + MP + 2], radius=5, fill=(8, 9, 11), outline=(90, 96, 106))
            d.text((x, y - 24), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "legend":
            _, x, y, lines = item
            mono = "DejaVuSansMono.ttf" if os.path.exists("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf") else "DejaVuSans.ttf"
            for j, ln in enumerate(lines): d.text((x, y + j * 28), ln, font=font(15, mono), fill=PRINT_DIM if j == 3 else PRINT)
        elif k == "cap":
            _, cx, cy, cap = item
            text_c(d, cx, cy, cap, font(11, "DejaVuSans.ttf"), PRINT)
    return im

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    defs = []
    for tab in TABS:
        bgname = f"ds_bg_{tab.lower()}.png"
        IMAGES[bgname] = background(tab)
        comps = [comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": bgname}, bounds((0, 0, W, H)))]
        for pl in sorted(PLACED[tab], key=lambda q: 1 if q["touch"] else 0):     # read-outs under, touch controls on top
            comps.append(comp(pl["name"], pl["dkey"], {"version": 1, "handleName": "Data"},
                              bounds((pl["x"], pl["y"], pl["w"], pl["h"]), focus="Yes" if pl["touch"] else "No", show="Hide" if pl["touch"] else "Show"),
                              {"version": 1, "map": [{"key": "Data", "value": f"Parameter {pl['param']}"}]}))
        DEFS[f"DS|{tab}"] = definition([], comps, "ff18191e")
    for k, v in DEFS.items(): defs.append({"key": k, "value": v})
    tabs = [{"version": 3, "tabName": t, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"DS|{t}", "initialSize": f"0 0 {W} {H}", "scale": 1.0} for i, t in enumerate(TABS)]
    tui = {"pageData": {"version": 1,
        "componentDefinitions": {"version": 2, "importFiles": ["/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
                                                                "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
                                 "localComponentDefinitions": defs},
        "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=2)
    qmap = lambda keys: {f"Q-Link {i + 1}": P[k] for i, k in enumerate(keys)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap(QL[t])} for i, t in enumerate(TABS)]},
         "Program Mode Q-Links": qmap(QL["DECK"])}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=2)
    total = 0
    for name, im in IMAGES.items():
        im.save(os.path.join(OUT, name), optimize=True); total += im.size[0] * im.size[1] * 4
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>scratchlab.vst.djscratch</identifier>\n"
        "\t<version>1.4.0.0</version>\n</plugincontent>\n")
    print(f"skin written to {SKIN_DIR}: {len(IMAGES) + 2} images, {total / 1e6:.1f} MB decoded")

# ---------- preview (what the screen should look like, drawn from the same layout) ----------
def preview(outdir):
    os.makedirs(outdir, exist_ok=True)
    vals = {"hold": 0, "auto": 1, "backspin": 0, "chop": 0, "fader": 0, "bypass": 0, "loop": 0, "tform": 0, "play": 1, "brake": 0,
            "reverse": 0, "rpm": 0, "pitchreset": 0, "rec": 1, "roll4": 0, "roll8": 1, "roll16": 0, "roll32": 0, "tform": 1, "savelast": 0, "cue": 0, "thru": 1, "rescan": 0,
            "spin": 0.15, "inmeter": 0.82, "pitch": 0.5 + 0.5 * (-3.2 / 8.0)}
    txt = {"throw": "1.00 s", "inertia": "12 ms", "release": "0.40 s", "output": "+0.0 dB", "return": "Slip (jump)", "catch": "3.0x",
           "spinspeed": "8.0x", "spintime": "1.20 s", "chopms": "80 ms", "cutms": "2.0 ms", "info": "REC 6.4s | LOOP 1/8  0.25 s  |  GATE 1/16",
           "looplen": "1/8", "bpm": "Host", "trate": "1/16", "tduty": "50 %", "tpat": "Straight", "source": "Live Input",
           "sample": "3/12 Fresh Ahh", "prange": "+/-8 %", "pfine": "+0.00 %", "bend": "+0.0 %", "startt": "0.50 s", "stopt": "0.80 s",
           "recsrc": "Output", "preroll": "1 s", "thresh": "On sound", "after": "Fades", "lastlen": "2 bars", "buflen": "20 s", "pitch": "-3.2 %"}
    inv = {v: k for k, v in P.items()}
    cache = {}
    def im_(n):
        if n not in cache: cache[n] = Image.open(os.path.join(OUT, n)).convert("RGBA")
        return cache[n]
    sheets = []
    for tab in TABS:
        im = im_(f"ds_bg_{tab.lower()}.png").copy(); d = ImageDraw.Draw(im)
        for pl in PLACED[tab]:
            x, y, w, h = int(pl["x"]), int(pl["y"]), int(pl["w"]), int(pl["h"]); key = inv[pl["param"]]; k = pl["kind"]
            if k == "record":
                fr = round(vals["spin"] * NUMFRAMES)
                for k2 in range(4): im.alpha_composite(im_(f"ds_record{k2}.png").crop((0, fr * PIECE, PIECE, fr * PIECE + PIECE)), (x + (k2 % 2) * PIECE, y + (k2 // 2) * PIECE))
            elif k == "pitch":
                fr = round(vals["pitch"] * NUMFRAMES)
                for k2 in range(NPITCH): im.alpha_composite(im_(f"ds_pitch{k2}.png").crop((0, fr * FPIECE, FPIECE, fr * FPIECE + FPIECE)), (int(x + (PSW - FPIECE) / 2), y + FY + k2 * FPIECE))
                text_c(d, x + w / 2, y + 11, txt["pitch"], font(13), LCD_TXT)
            elif k == "meter":
                fr = round(vals["inmeter"] * NUMFRAMES)
                for k2 in range(MN): im.alpha_composite(im_(f"ds_meter{k2}.png").crop((0, fr * MP, MP, fr * MP + MP)), (x + k2 * MP, y))
            elif k in ("key", "bigkey"):
                pre = "ds_bigkey" if k == "bigkey" else "ds_key"
                im.alpha_composite(im_(f"{pre}_{'on' if vals.get(key, 0) >= 0.5 else 'off'}.png"), (x, y))
            elif k in ("box", "text"):
                s = txt[key].upper() if k == "box" else txt[key]
                size = 15 if k == "box" else int(pl["extra"] * 0.8); f = font(size)
                while d.textlength(s, font=f) > w - 8 and size > 7: size -= 1; f = font(size)
                text_c(d, x + w / 2, y + h / 2, s, f, LCD_TXT)
        path = os.path.join(outdir, f"skin-preview-{tab.lower()}.png")
        im.convert("RGB").save(path); sheets.append(im.convert("RGB")); print("preview:", path)
    sheet = Image.new("RGB", (W, H * len(sheets) + 10 * (len(sheets) - 1)), (0, 0, 0))
    for i, s in enumerate(sheets): sheet.paste(s, (0, i * (H + 10)))
    sheet.resize((sheet.size[0] // 2, sheet.size[1] // 2), Image.LANCZOS).save(os.path.join(outdir, "skin-preview-all.png"))

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
